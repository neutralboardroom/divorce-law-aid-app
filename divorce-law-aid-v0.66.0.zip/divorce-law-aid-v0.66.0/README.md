# Divorce Law Aid v0.55.0

Divorce Law Aid is an English-first New York legal-information, preparation, professional-directory and attorney-demonstration portal coordinated with Smarter Justice.

v0.55.0 adds an exact-tested private uncontested-divorce filing-readiness map and refreshes current 2026 official New York Courts form guidance. It separately adds six lawful, source-reviewed Upstate attorney profiles while preserving unclaimed, registration-pending and availability-unverified boundaries. The release is governed by the exact V12 balanced-material packet and a 226-rule shared ledger.

## Local validation

```bash
npm ci --ignore-scripts
npm run build
npm test
npm run audit
```

Deployment, post-deployment verification, browser acceptance and live acceptance are not claimed.
