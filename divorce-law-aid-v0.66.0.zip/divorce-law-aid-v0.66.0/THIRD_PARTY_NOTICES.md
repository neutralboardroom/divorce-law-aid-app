# Third-Party Notices

The runtime application has no third-party package dependency. It uses Node.js built-in modules and system-safe fonts. No third-party font files, stock logos, biographies, photographs, reviews, ratings or commercial directory datasets are packaged.

Public links and source records identify New York State Unified Court System pages, the New York State Office for the Prevention of Domestic Violence, and official professional websites. Their content remains owned by their respective publishers and is linked rather than republished.
