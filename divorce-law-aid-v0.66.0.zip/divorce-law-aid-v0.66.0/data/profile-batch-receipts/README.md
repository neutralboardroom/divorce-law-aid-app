# Profile batch receipts

Controlled local profile-growth commands write deterministic operator-readable JSON receipts here. Receipts contain source and validation outcomes, not private identity evidence or public-user matter data.
