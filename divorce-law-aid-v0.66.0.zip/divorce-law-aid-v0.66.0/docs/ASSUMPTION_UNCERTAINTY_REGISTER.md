> Current release: v0.66.0. Directory truth: 465 profiles, 258 attorneys, 207 firms, 236 approved attorney-to-firm relationships.

# Assumption and Uncertainty Register — v0.66.0

- Directory counts are exact source-derived current facts: 440 profiles, 233 attorneys, 207 firms, 211 approved relationships.
- Official attorney-registration reviews completed: 0; 233 tasks remain. External-link checks executed: 0; 440 tasks remain.
- Packaged contract version `1.4.0` and executable adapter version `0.64.0` do not prove a current Smarter Justice producer/consumer contract. Complete-ladder maturity is **D0 NOT CURRENTLY VERIFIED**.
- Browser acceptance is blocked by `net::ERR_BLOCKED_BY_ADMINISTRATOR`; no pass is claimed.
- Outer ZIP identity is computed after final packaging and is not recursively embedded.
- No deployment, payment, live opportunity, live outreach, confidential upload, OCR, external AI, or alternate-language activation is inferred.
