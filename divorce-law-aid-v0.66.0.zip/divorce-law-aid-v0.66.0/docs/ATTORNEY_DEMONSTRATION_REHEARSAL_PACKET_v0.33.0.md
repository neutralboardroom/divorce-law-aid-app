# Attorney Demonstration Rehearsal Packet — v0.33.0

Status: **ready after exact staging deployment; not human-accepted**.

Packet ID: `DLA-0.33.0-ATTORNEY-DEMONSTRATION-REHEARSAL`  
Packet digest: `530b8f0c2f170143d0face9c5419484068fe7a19d966c09a60651a755674145a`

## Duration scenarios

- **15 seconds:** Specialty, free public value, canonical profile quality, and professional credibility are immediately understandable.
- **2 minutes:** Homepage, search, real attorney page, supported firm page, and memory-first tool can be shown without a broken or gated stop.
- **10 minutes:** Free claim/correction rights, exact $15 pilot pricing, central Smarter Justice authority, no-guarantee language, QR continuation, and next action are clear.

## Exact routes

- `/` — first impression — `fbdcdba7001fd07cedb5016577495044598d71a87113a124daeaf28b85e10c3b`
- `/directory.html?type=Attorney` — attorney search — `54db42d2c9afd06f6b540d15581212c5d2b474534ae20e9453987744939fb36b`
- `/attorneys/andrea-b-friedman/` — real exemplary attorney profile — `7a477c433606ae2ad912db3aa83bd2023bc93ac069a107e2a46588b1c8bcdc02`
- `/firms/friedman-friedman-pllc-attorneys-at-law/` — supported exemplary firm profile — `4a077a28a5734bffca11decdf6f53e07c0e3dce42cfbfbf327c13d977d03a836`
- `/questions.html?demo=1` — safe memory-first public tool — `0e1b6eef2d5ed27fffa151e86cd8000c6a7181c9d97dd8f8e477b563a4503f5e`
- `/documents.html` — Document Help — `a1cd01b216d9c00614f96915fdea62ae351f314fe9e6631ca082d9c451b602f4`
- `/for-professionals.html` — professional value and $15 pilot — `1dd714bcce3e5deb25792bdf2adbb53603d3d1e774cccb5ca8f684e0b7c03146`
- `/claim-profile.html` — free claim boundary — `a5ec28a69713f1920db1d948d60b55b4a1aa30ac23c26af2e57801938ed7fbb3`
- `/demo.html` — self-guided tour — `8c23874aeceb1c687d366ce14fdbdd7dabed750c4e35b2dc44c9bd155487b23e`

## Safe rehearsal boundary

- No private user data
- No fictional professional or result
- Safe synthetic questions example can be cleared
- QR and links contain no private data
- No checkout or live-integration claim

Bind the completed record to the immutable deployment and release-candidate IDs. No private user, payment, credential, or client data belongs in the rehearsal.
