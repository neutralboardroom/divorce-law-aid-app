# Attorney Demonstration Rehearsal Packet — v0.34.0

Status: **ready after exact staging deployment; not human-accepted**.

Packet ID: `DLA-0.34.0-ATTORNEY-DEMONSTRATION-REHEARSAL`  
Packet digest: `de36080257422af3e168c94d7bd430fc1a6bd2cd0d6e1cbc9f59ff5abb60b767`

## Duration scenarios

- **15 seconds:** Specialty, free public value, canonical profile quality, and professional credibility are immediately understandable.
- **2 minutes:** Homepage, search, real attorney page, supported firm page, and memory-first tool can be shown without a broken or gated stop.
- **10 minutes:** Free claim/correction rights, exact $15 pilot pricing, central Smarter Justice authority, no-guarantee language, QR continuation, and next action are clear.

## Exact routes

- `/` — first impression — `fbdcdba7001fd07cedb5016577495044598d71a87113a124daeaf28b85e10c3b`
- `/directory.html?type=Attorney` — attorney search — `54db42d2c9afd06f6b540d15581212c5d2b474534ae20e9453987744939fb36b`
- `/attorneys/andrea-b-friedman/` — real exemplary attorney profile — `7a477c433606ae2ad912db3aa83bd2023bc93ac069a107e2a46588b1c8bcdc02`
- `/firms/friedman-friedman-pllc-attorneys-at-law/` — supported exemplary firm profile — `4a077a28a5734bffca11decdf6f53e07c0e3dce42cfbfbf327c13d977d03a836`
- `/questions.html?demo=1` — safe memory-first public tool — `0e1b6eef2d5ed27fffa151e86cd8000c6a7181c9d97dd8f8e477b563a4503f5e`
- `/documents.html` — Document Help — `a1cd01b216d9c00614f96915fdea62ae351f314fe9e6631ca082d9c451b602f4`
- `/for-professionals.html` — professional value and $15 pilot — `d5d85263e4b601b6da6003db8b1db45d4fa2168eb4f47761f7e340a2af9aed7e`
- `/claim-profile.html` — free claim boundary — `ab2fd497adf0d43141550cb35360d0cdeea423a9f5c1e74203348038c3227f3a`
- `/demo.html` — self-guided tour — `245e16f13f7a63fb4714e2df6303642203d4f88772cad0d258bf021f2c3d34ec`

## Safe rehearsal boundary

- No private user data
- No fictional professional or result
- Safe synthetic questions example can be cleared
- QR and links contain no private data
- No checkout or live-integration claim

Bind the completed record to the immutable deployment and release-candidate IDs. Rehearse on at least one real phone and one real laptop or desktop. The portal may be labeled ATTORNEY-DEMONSTRATION ACCEPTED only after the human rehearsal passes and a scoped owner outreach-use decision is recorded. A narrow residual-risk decision may not waive safety, privacy, security, legal false claims, a broken critical journey, or a material accessibility defect. No private user, payment, credential, or client data belongs in the rehearsal.
