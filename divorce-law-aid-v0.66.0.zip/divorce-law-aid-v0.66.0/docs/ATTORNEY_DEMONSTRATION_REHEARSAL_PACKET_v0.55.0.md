# Attorney Demonstration Rehearsal Packet — v0.55.0

Status: **ready after exact staging deployment; not human-accepted**.

Packet ID: `DLA-0.55.0-ATTORNEY-DEMONSTRATION-REHEARSAL`  
Packet digest: `d4753c5f0659defea8f82ea01582c3e17bd5cb1efe92a07ad20eb4916d3c9aca`

## Duration scenarios

- **15 seconds:** Specialty, free public value, canonical profile quality, and professional credibility are immediately understandable.
- **2 minutes:** Homepage, search, real attorney page, supported firm page, and memory-first tool can be shown without a broken or gated stop.
- **10 minutes:** Free claim/correction rights, exact $15 pilot pricing, central Smarter Justice authority, no-guarantee language, QR continuation, and next action are clear.

## Exact routes

- `/` — first impression — `fbdcdba7001fd07cedb5016577495044598d71a87113a124daeaf28b85e10c3b`
- `/directory.html?type=Attorney` — attorney search — `f55d493c9a09ac9bf50c0cd460a63d0863a49ca3381e1c19df23da6484c4269a`
- `/attorneys/andrea-b-friedman/` — real exemplary attorney profile — `7a477c433606ae2ad912db3aa83bd2023bc93ac069a107e2a46588b1c8bcdc02`
- `/firms/friedman-friedman-pllc-attorneys-at-law/` — supported exemplary firm profile — `4a077a28a5734bffca11decdf6f53e07c0e3dce42cfbfbf327c13d977d03a836`
- `/questions.html?demo=1` — safe memory-first public tool — `0e1b6eef2d5ed27fffa151e86cd8000c6a7181c9d97dd8f8e477b563a4503f5e`
- `/documents.html` — Document Help — `f1fdab3c00c4a8c3574bb894eb5d1bb6bfd30b81169f63f7447cd7ac55c4f3f0`
- `/for-professionals.html` — professional value and $15 pilot — `9b66cd400df2d373263f1e842ec4e9d6b8da8f1d05c0085e9a496b3b515ebb00`
- `/claim-profile.html` — free claim boundary — `ab2fd497adf0d43141550cb35360d0cdeea423a9f5c1e74203348038c3227f3a`
- `/demo.html` — self-guided tour — `440cf9b0ec35e37ec4aa98bf147d9c7d944308cb439d24cfbc1db1704f29e6a1`

## Safe rehearsal boundary

- No private user data
- No fictional professional or result
- Safe synthetic questions example can be cleared
- QR and links contain no private data
- No checkout or live-integration claim

Bind the completed record to the immutable deployment and release-candidate IDs. Rehearse on at least one real phone and one real laptop or desktop. The portal may be labeled ATTORNEY-DEMONSTRATION ACCEPTED only after the human rehearsal passes and a scoped owner outreach-use decision is recorded. A narrow residual-risk decision may not waive safety, privacy, security, legal false claims, a broken critical journey, or a material accessibility defect. No private user, payment, credential, or client data belongs in the rehearsal.
