# Attorney Outreach Demonstration Standard

The public `/demo.html` route provides a concise, privacy-safe five-stop path: homepage, attorney directory, one exemplary canonical attorney page, Document Help, and professional value/continuation. It exposes no private user data and does not imply that membership, claims, payment, outreach, or opportunity delivery is active. The QR target is `https://divorcelawaid.com/demo.html`.

The demonstration must remain usable on a phone, load without broken states, identify seeded profiles truthfully, and provide a direct continuation path after an in-person visit.
