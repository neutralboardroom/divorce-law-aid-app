# Attorney Outreach Profile Review Queue — v0.66.0

Status: **operator prioritization only**. No registration check, source-link check, outreach delivery, claim, payment, membership, availability or attorney participation is represented as complete.

This deterministic queue prioritizes the current 240 public attorney profiles for the exact independent reviews still required before broad promotion or live professional use. Payment, claim status and sponsored status do not affect the score or public directory order. Active suppression or removal records are excluded.

## Current review burden

- Visible attorney profiles: 258.
- Official registration checks still required: 258.
- External source-link checks still required: 258.
- Approved attorney-to-firm relationships represented in the queue: 236.
- Outreach delivery remains closed.

## First 25 review candidates

1. **Alexander M. Dudelson** — Brooklyn; tier A; score 135; required: official attorney-registration review, external source-link check; [public profile](/attorneys/alexander-m-dudelson/)
2. **Helene Bernstein** — Brooklyn; tier A; score 135; required: official attorney-registration review, external source-link check; [public profile](/attorneys/helene-bernstein/)
3. **Maria Coffinas** — Brooklyn; tier A; score 135; required: official attorney-registration review, external source-link check; [public profile](/attorneys/maria-coffinas/)
4. **Meredith A. Lusthaus** — Brooklyn; tier A; score 135; required: official attorney-registration review, external source-link check; [public profile](/attorneys/meredith-a-lusthaus/)
5. **Meredith Lauren Singer** — Brooklyn; tier A; score 135; required: official attorney-registration review, external source-link check; [public profile](/attorneys/meredith-lauren-singer/)
6. **Theodore Alatsas** — Brooklyn; tier A; score 135; required: official attorney-registration review, external source-link check; [public profile](/attorneys/theodore-alatsas/)
7. **Gabrielle Lazzaro** — Brooklyn; tier A; score 131; required: official attorney-registration review, external source-link check; [public profile](/attorneys/gabrielle-lazzaro/)
8. **Abby P. Rosmarin** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/abby-p-rosmarin/)
9. **Adam John Wolff** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/adam-john-wolff/)
10. **Alexandra C. Franco** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/alexandra-c-franco/)
11. **Alison M. Trainor** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/alison-m-trainor/)
12. **Allan E. Mayefsky** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/allan-e-mayefsky/)
13. **Allison Grinspoon** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/allison-grinspoon/)
14. **Anna Feldberg** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/anna-feldberg/)
15. **Anthony Balzofiore** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/anthony-balzofiore/)
16. **Audrey A. Youn** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/audrey-a-youn/)
17. **Barry Berkman** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/barry-berkman/)
18. **Bernadette N. Schneider** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/bernadette-n-schneider/)
19. **Carly Krasner Leizerson** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/carly-krasner-leizerson/)
20. **Cassandra R. Volkheimer** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/cassandra-r-volkheimer/)
21. **Dana M. Stutman** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/dana-m-stutman/)
22. **Daniel Brickley** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/daniel-brickley/)
23. **Daphne Schechter** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/daphne-schechter/)
24. **David Aronson** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/david-aronson/)
25. **Deborah E. Lans** — Manhattan; tier A; score 130; required: official attorney-registration review, external source-link check; [public profile](/attorneys/deborah-e-lans/)

## Profile-growth decision

Seven source-reviewed profiles were added through the separately validated v0.66.0 growth batch. This queue does not add or verify profiles; it provides a deterministic way to work through the registration and link-review burden for all current attorneys while outreach delivery remains closed.
