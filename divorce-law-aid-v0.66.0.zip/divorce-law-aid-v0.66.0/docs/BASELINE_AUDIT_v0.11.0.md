# Reproduced v0.11.0 baseline before v0.12.0 work

The owner directed that the uploaded `divorce-law-aid-v0.11.0(1).zip` be treated as authoritative because the previously described v0.12.0 artifact was never finished.

## Exact uploaded identity

- SHA-256: `539ab77b6613dc08e2d730c99ce5e62cc72a697205787fe00d29832e9920d6eb`
- Size: 621,669 bytes
- ZIP entries: 148
- Files: 134
- Explicit directories: 14
- Repository root: `divorce-law-aid-v0.11.0/`
- Package version: 0.11.0
- Node requirement: 22.x
- Runtime dependencies: 0

## Reproduced baseline

- Clean `npm ci --ignore-scripts --omit=dev`: passed
- `npm audit --omit=dev --ignore-scripts`: 0 reported vulnerabilities
- Automated tests: 77 passed
- Application audit: 134 files, 46 public HTML pages, 14 JSON files, 162 profiles and 61 source records
- Deployment: false
- Sensitive traffic: closed

## Material gap selected for v0.12.0

The directory had one generic client-rendered profile shell rather than stable canonical attorney and firm pages. The artifact also lacked a locally testable, minimized read-only Smarter Justice projection adapter, import receipts and last-known-good rollback behavior.

## Non-goals

No legal-content expansion, registration verification, live claim approval, public-user account system, billing, sponsorship, inquiry routing, confidential uploads, OCR, outside AI, filing, service, e-signature, notarization or deployment was authorized.
