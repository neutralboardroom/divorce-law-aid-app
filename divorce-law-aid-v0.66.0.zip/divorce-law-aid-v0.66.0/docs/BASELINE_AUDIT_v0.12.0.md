# Baseline Audit — Divorce Law Aid v0.12.0

Prepared July 29, 2026, America/New_York.

## Exact source identity

- Candidate: `divorce-law-aid-v0.12.0.zip`
- Classification: EXACT VERIFIED in this dedicated chat
- SHA-256: `6af9d0be56f05802e18bacf44318b04f93ccf294cea7b048ef988520f72647c4`
- Exact size: `1,305,878 bytes`
- Repository root: `divorce-law-aid-v0.12.0/`
- ZIP entries: 495; packaged files: 315; explicit directories: 180
- Node: 22.x; runtime dependencies: 0
- Deployment: not deployed; sensitive traffic closed

## Reproduced baseline

Clean extraction, clean install, zero-vulnerability audit, 88 automated tests, application audit, local route/API/security acceptance, and controlled Chromium checks reproduced before v0.13.0 implementation. The baseline contained 208 public HTML pages, 22 canonical attorney pages, 140 canonical firm pages, and 162 public-information records.

## Material baseline limitations

- Professional claim links relied on direct trust-based central query parameters rather than signed short-lived state.
- Profile growth and currentness work lacked a repeatable batch, source-admissibility, queue, receipt, and owner-review operation.
- Directory rendering placed all matching records in the DOM at once.
- Public source-review dates were not clearly distinguished from official registration review.
- Firm-attorney links were absent because the source data did not prove relationships.
- No live support, real-device acceptance, independent legal review, production integration, or external currentness recheck was proven.

## Baseline acceptance decision

The exact source was suitable for a material v0.13.0 build. No secret, unsafe path, production dump, irreversible migration, or incompatible repository root was found.
