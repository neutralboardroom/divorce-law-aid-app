# Exact Baseline Audit — Divorce Law Aid v0.13.0

The untouched starting artifact was `divorce-law-aid-v0.13.0.zip`.

- SHA-256: `06e9f1f446a8f524b0441d250dcb7b22865fffaf84fe04b768f6c9e8a0618ce3`
- Exact size: `1,350,732 bytes`
- ZIP entries: 523, including 341 files and 182 explicit directories
- Repository root: `divorce-law-aid-v0.13.0/`
- Manifest records/hash: 340 / `f4ffa3d23c2c9f187bbe51e5c38e45341319b3083fe4c6c7f8b5ce5d332168e2`
- Runtime: Node.js 22.x; zero runtime dependencies
- Baseline tests: 96 passed
- Baseline public HTML: 208
- Baseline profiles: 162 public unclaimed; 22 attorney; 140 firm
- Deployment: not deployed; sensitive and commercial gates closed

CRC, path safety, clean extraction, manifest, clean install, zero-vulnerability audit, application audit, tests, local route/API/security checks, and controlled browser acceptance were reproduced before v0.14.0 source changes. The baseline remains available for comparison and the exact v0.13.0 ZIP remains the rollback artifact.
