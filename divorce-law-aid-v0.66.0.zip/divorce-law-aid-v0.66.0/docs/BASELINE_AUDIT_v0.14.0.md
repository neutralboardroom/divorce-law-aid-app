# Baseline Audit — exact v0.14.0

- Authoritative base: `divorce-law-aid-v0.14.0.zip`.
- SHA-256: `7c684e6f4a8d0898b84db9e13e0e5b4cd1418a92587d22a75f2de8fbb7afcf27`.
- Exact size: 1,398,054 bytes.
- ZIP entries: 535; packaged files: 353; explicit directories: 182.
- Repository root: `divorce-law-aid-v0.14.0/`.
- Source manifest records: 352; manifest SHA-256 `746bb5af3f1614a396ee6e6f757ad94eede88f7e613b8e4577a64bae44691485`.
- Baseline application: 209 public HTML pages; 162 public-information profiles; 22 attorney pages; 140 firm pages; zero runtime dependencies.
- Reproduction before v0.15.0 changes: CRC/path safety, clean extraction, clean install, zero-vulnerability audit, all 102 tests and application audit passed.
- Deployment remained false; D4/D5 integration and all commercial/sensitive gates remained closed.
