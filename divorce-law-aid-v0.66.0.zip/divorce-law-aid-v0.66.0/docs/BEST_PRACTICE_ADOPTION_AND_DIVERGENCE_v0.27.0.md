# Best-Practice Adoption and Divergence — v0.27.0

Machine-readable record: `data/best-practice-adoption-v0.27.0.json`.

Adopted: source-derived current release truth, exact current authority, and release-specific rollback.

Adapted: the independent validator reimplements material counts and states for Divorce Law Aid’s canonical profile, route, currentness, language, gate, adapter, and release structures.

Rejected with evidence: automatic public language expansion before complete translated journeys and qualified review.

Verify before adoption: newer central field ownership, firm/office/seat authority, billing, entitlement, notification, and opportunity behavior because no exact current Smarter Justice contract was supplied in this builder chat.
