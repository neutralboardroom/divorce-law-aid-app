# Bounce and Complaint Standard

Live delivery is closed. Before activation, hard bounces must suppress the address, complaints must stop follow-up and may pause the whole campaign, and thresholds must have named owners. Results require immutable receipts and cannot be hidden to optimize claim conversion. No bounce or complaint is recorded in this artifact.
