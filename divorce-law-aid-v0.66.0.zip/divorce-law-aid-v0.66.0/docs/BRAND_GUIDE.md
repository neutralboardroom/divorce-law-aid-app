# Divorce Law Aid Brand Guide

## Current selection

“Bridge Paths” remains the provisional mark in v0.11.0. Logo selection is intentionally deferred at Roger’s direction and is not a deployment blocker for this product-and-language refinement. The two materially different alternatives remain under `public/assets/img/brand/concepts/`; no logo assets were redesigned merely to create a new version.

## Meaning

A protective arch holds a neutral starting point while two distinct paths move forward. The mark avoids broken-heart, broken-ring, adversarial, courthouse, gavel, and government-seal imagery.

## Palette

Deep Indigo `#24324A`; Harbor Blue `#3E6C8A`; Calm Sage `#6F8E7E`; Warm Ivory `#FAF7F2`; Soft Sky `#EEF4F7`; Muted Gold `#A66F22`; Ink `#1D2733`; Muted Text `#5B6675`; Danger `#A6251B`.

## Typography

System-safe interface stack: Inter when locally available, then `system-ui`, Segoe UI, and sans-serif. No remote font service and no packaged font file.

## Use

Keep clear space equal to the icon’s gold center stroke around the mark. Do not distort, rotate, recolor, add a government seal, place on noisy imagery, or imply court or law-firm affiliation. Use the compact icon below 140 CSS pixels.
