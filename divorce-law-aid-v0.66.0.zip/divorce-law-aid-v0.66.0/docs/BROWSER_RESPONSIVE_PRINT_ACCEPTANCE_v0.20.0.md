# Browser, Responsive and Print Acceptance — v0.20.0

Controlled Chrome 144 acceptance passed on July 29, 2026 after temporarily isolating and then restoring the container-managed localhost URL policy.

- Static route inventory coverage: 282 public HTML pages.
- 18 desktop key-route checks.
- 54 responsive key-route checks.
- 72 total page/viewport checks at 1440, 1024, 430 and 320 CSS pixels.
- Directory progressive disclosure: 24 initial listings and 48 after activation.
- Consultation packet, guided form, marital-draft, document-review, review-package, workspace-recovery and opportunity-disclosure interactions passed.
- 12 print/PDF checks passed.
- Horizontal overflow failures: 0.
- Broken-image failures: 0.
- Rendered-content failures: 0.

This is controlled local browser evidence, not live URL, real-device, screen-reader or production acceptance.
