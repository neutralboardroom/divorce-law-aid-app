> Current release: v0.66.0. Directory truth: 465 profiles, 258 attorneys, 207 firms, 236 approved attorney-to-firm relationships.

# Builder Opportunity Discovery Register — v0.66.0

The exact v0.37.0 baseline reproduced cleanly, including its byte-idempotent build, stable source manifest, and deterministic opportunity receipt-chain evidence. A deeper evidence audit independently found a separate connected gap across protected synthetic operator commands. Identical claim-verification, outreach, and profile-growth dry-runs changed timestamps or output digests because hidden wall-clock time entered the path; profile-growth dry-run could also write packaged receipt evidence. Profile-review and relationship dry-runs were already stable but were not governed by one complete family contract.

v0.46.0 closes the full boundary with a shared explicit-clock contract, byte-identical repeated outputs across all five families, missing-clock and synthetic-apply rejection where applicable, no dry-run receipt persistence, complete packaged-source non-mutation, and current-truth/evidence/checkpoint/manifest/source-manifest/exact-artifact integration. Real operational timestamps remain authentic and separate.

Profile additions remain zero under the review-capacity exception because all 143 attorney-registration reviews and all 350 external-link checks remain outstanding. Adding volume is independent and would increase unresolved currentness burden.
