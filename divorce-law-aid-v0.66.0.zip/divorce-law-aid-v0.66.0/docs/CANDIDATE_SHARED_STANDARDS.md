# Candidate Shared Standards — v0.39.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.39.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

- **CSS-DLA-021-01 — Attorney-first corrective growth.** Track individual attorney and firm counts separately; a firm page never substitutes for a professional page.
- **CSS-DLA-021-02 — Registration-pending public seed.** Permit a source-supported unclaimed attorney page only with explicit pending status and blocked claim/verified/opportunity gates until official review.
- **CSS-DLA-021-03 — Bidirectional relationship approval.** Require exact source evidence, accountable decision and atomic attorney/firm linkage.
- **CSS-DLA-021-04 — Individual coverage transparency.** Publish exact attorney, firm, linked and pending counts without implying participation or current registration.
- **CSS-DLA-021-05 — Repository-specific four-portal application.** Shared rules may be adopted; specialty-specific safety and profile classes require exact local evidence.
