# Change Map — v0.66.0

- Bind exact v0.65.0 under V14 `EXISTING_CHAT_PACKET_ONLY`.
- Add private local-only mediation preparation with five fail-closed states and current official-source boundaries.
- Add five source-reviewed Rower LLC attorney profiles through candidate and human-publication review.
- Add five approved attorney-to-firm relationships and append-only firm enrichment.
- Advance browser-local storage to `dla-v0.66.0` with exact `dla-v0.65.0` first in the prior-key chain.
- Preserve billing, AI, deployment and live-operation gates as closed and unclaimed.
