# Claim Dispute and Appeal Standard

Conflicting, impersonation, former-authority and profile-ownership claims enter an explicit disputed state. A reason, operator and audit event are required. Control may be suspended while reviewed. Appeals do not bypass identity, professional-status or exact-profile authority checks. Revoked control may be restored only through a newer verified revision.
