# Claim Evidence and Data-Minimization Standard

The portal register stores identifiers, revision, decision state, scoped authority and non-document evidence references only. It rejects passwords, sessions, MFA secrets, recovery codes, identity documents, credential documents, raw claim evidence, staff/support notes and payment-card data. Raw evidence remains within the approved central Smarter Justice review system, not the public portal projection or release package.
