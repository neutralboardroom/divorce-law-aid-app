# Claim, Publication and Outreach Test Report — current through v0.39.0

Claim control remains separated into account/email, identity, current professional status, exact-profile authority, specialty, firm authority and staff approval. All 350 profiles remain unclaimed and no pending state grants public control.

The v0.27.0 human publication batch accepted 17 public-unclaimed attorney seeds and contains no automatic publication. Outreach delivery, automation, SMTP, SMS and calling remain closed. No live recipients, sends, deliveries, bounces, complaints or opt-outs are recorded.

Automated regression, application audit, local server/security checks and configured/fail-closed handoff checks preserve these boundaries.
