# Claim Verification Standard — v0.39.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.39.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

Profile control is free and fail closed. Before local acceptance of a central decision, the exact claim must show: verified central account/email, verified identity, verified current professional status, verified authority for the exact local attorney or firm profile, and approved staff decision. Each check needs a non-document evidence reference. Specialty eligibility and publication remain separate.

Email alone, matching name, public facts, payment, a profile URL or a claim link never proves identity or authority. Pending claims may submit evidence but cannot publish protected changes, display a claimed/verified state, suppress another person's page, activate opportunities or change organic rank.

Restrictive actions require a reason. Revisions must increase; replay, stale revisions, wrong portal IDs and prohibited private evidence are rejected.
