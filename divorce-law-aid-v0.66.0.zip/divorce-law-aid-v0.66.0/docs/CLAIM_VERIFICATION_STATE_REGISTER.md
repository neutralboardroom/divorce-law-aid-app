> Current release: v0.66.0. Directory truth: 465 profiles, 258 attorneys, 207 firms, 236 approved attorney-to-firm relationships.

# Claim Verification State Register — v0.66.0

Current public truth: 440 profiles are unclaimed; public claimed profiles: 0; live claims: 0. Claim control remains fail closed and centrally dependent. Account/email, identity, professional status, exact-profile authority, firm authority where applicable, staff approval, specialty eligibility, and publication status are separate.

An active suppression/removal tombstone blocks profile control. Payment never establishes identity, truth, authority, publication, verification, rank, or outcomes.
