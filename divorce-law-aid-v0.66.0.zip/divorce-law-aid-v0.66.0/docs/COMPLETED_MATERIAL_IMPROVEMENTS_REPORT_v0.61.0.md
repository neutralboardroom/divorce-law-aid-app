# Completed Material Improvements — v0.61.0

## Product

- Added a private no-upload document-sharing safety planner with deterministic stop states and human-review-only output.
- Added six source-reviewed Manhattan matrimonial attorney profiles and six approved relationships to an existing firm.
- Preserved unclaimed, registration-pending, availability-unverified, nonsponsored and unenhanced profile boundaries.
- Preserved deterministic public tools, dark billing, dark AI, closed deployment gates and exact v0.60.0 rollback.

## Builder and prompt system

- Bound exact v0.60.0 under V14 `NEW_CHAT_NEXT_VERSION`.
- Added a dedicated document-sharing boundary validator.
- Added immediate-predecessor browser migration regression coverage.
- Preserved self-excluding payload inventory and non-self-referential owner receipt generation.
