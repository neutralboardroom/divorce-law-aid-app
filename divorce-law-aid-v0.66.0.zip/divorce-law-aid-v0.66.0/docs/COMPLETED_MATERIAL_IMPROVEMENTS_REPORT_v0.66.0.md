# Divorce Law Aid v0.66.0 — Completed Material Improvements

Release clock: `2026-08-04T11:30:00-04:00`  
V14 mode: `EXISTING_CHAT_PACKET_ONLY`  
Exact predecessor: `divorce-law-aid-v0.65.0.zip` / `6738274b5ddc4a4409da3e8f23db3ce8256aa575c60e87006b281e83055a55aa` / `18206516` bytes

## Product track

- Added a private, local-only court-appearance preparation organizer.
- Added five deterministic stop states covering notice/source, date/time/method/check-in, expected items, access/safety needs, and virtual authorization/technology.
- Added three source-reviewed Manhattan attorney profiles and three approved Moore Family Law relationships.
- Kept registration, current office address, availability, billing, AI, deployment and live acceptance closed or unclaimed.

## Prompt and builder track

- Bound the exact v0.62.0 predecessor and V14 packet before editing.
- Added current official court-source evidence and a dedicated court-appearance validator.
- Strengthened exact successor, rollback, current-batch and browser-migration checks.
- Preserved self-excluding release receipts and deterministic fresh-extraction acceptance.
