# Continuation Snapshot — v0.30.0

The complete machine-readable snapshot is `data/continuation-snapshot-v0.30.0.json`.

It records the exact sixteenth-pass prompt identity, exact v0.29.0 predecessor, Mode A authority, current 350/143/207/121 product truth, 409 pages, 412 routes, 964 review tasks, five open Owner Assistance Requests, D0 professional integration paths, rollback, open gates, and the exact next executable command.

A fresh builder chat should receive the exact v0.30.0 ZIP, this snapshot, and the exact sixteenth-pass prompt file. The full master prompt need not be pasted repeatedly into progress messages.
