# Coordinated Builder Authority — v0.46.0

- Current V7 pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Exact packet SHA-256: `80ae674c6fb932fc9e675052821753168d1c385bfb2c12d41113739c357f9245`
- Durable baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Rules: 86 master + 36 owner + 36 builder = 158
- Global superseded tombstones: ODR-010, ODR-021, BDR-021
- Conditional rules: ODR-012, BDR-019, BDR-022, BDR-023
- Exact manifested files verified: 18/18
- Product applicability ledger and launch-readiness receipt are mandatory and separately validated.
- Deployment, production authorization, post-deploy verification and live acceptance are not claimed.
