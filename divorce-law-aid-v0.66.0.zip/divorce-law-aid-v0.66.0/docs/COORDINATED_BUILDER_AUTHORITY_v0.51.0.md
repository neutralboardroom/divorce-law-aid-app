# Coordinated Builder Authority — v0.51.0

- Current V8 pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Exact packet SHA-256: `2abb1d036b0970c305ec360888fe78a490650f9b72f2f8e7a747932741dfdd97`
- Durable baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Rules: 86 master + 42 owner + 42 builder = 170
- Global superseded tombstones: ODR-010, ODR-021, BDR-021
- Conditional rules: ODR-012, BDR-019, BDR-022, BDR-023
- Exact manifested files verified: 20/20
- Product applicability ledger and launch-readiness receipt are mandatory and separately validated.
- Deployment, production authorization, post-deploy verification and live acceptance are not claimed.
