# Coordinated Builder Authority — v0.52.0

- Current V9 pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Exact packet SHA-256: `9fdddde697ed2562dc22e83efe95b52836ca996d5976f2a21bcdb66a64b87610`
- Durable baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Rules: 86 master + 43 owner + 43 builder = 172
- Global superseded tombstones: ODR-010, ODR-021, BDR-021
- Conditional rules: ODR-012, BDR-019, BDR-022, BDR-023
- Exact manifested files verified: 20/20
- Product applicability ledger and launch-readiness receipt are mandatory and separately validated.
- Deployment, production authorization, post-deploy verification and live acceptance are not claimed.
