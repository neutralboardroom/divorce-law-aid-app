# Cross-Portal Learning Packet — v0.46.0

## Candidate shared practices

1. Treat global rule successorship as authoritative: inherit explicit tombstones instead of reviving superseded workflow rules.
2. Distinguish conditional rules whose trigger is absent from rules that are satisfied or not applicable.
3. Produce a complete product applicability ledger and exception-first launch-readiness receipt rather than copying authority files without product evidence.
4. Test rollback filename, hash and size as one indivisible identity; a matching hash with the wrong filename is a release defect.
5. Enrich existing profiles through append-only provenance while preserving the source record that established the original listing.

## Exact target evidence

- `data/coordinated-builder-authority-v0.46.0.json`
- `data/durable-rule-applicability-ledger-v0.46.0.json`
- `data/product-launch-readiness-receipt-v0.46.0.json`
- `data/rollback-plan-v0.46.0.json`
- `tests/v046.test.js`
- strengthened `scripts/exact-artifact-test.js`

## Applicability and limits

Adopt or adapt these controls where another product receives the same V7 authority. Do not copy Divorce Law Aid statuses, exceptions, source evidence, counts, readiness, or acceptance to another product. Each product must bind its own implementation, exact predecessor, external blockers, protected actions, tests, and rollback.
