# Currentness and Refresh Plan — current after v0.39.0

Current deterministic schedule: 964 tasks across 350 profiles and 121 relationships. It includes 350 practice-source rechecks, 350 external-link checks, 143 official attorney-registration checks, and 121 relationship-evidence rechecks.

Priority order: official registration identity/status review for all 143 attorneys; external-link execution for all 350 profiles; relationship evidence recheck for all 121 approved links; then recurring practice-source review according to policy. Every applied batch requires dated evidence, accountable operator identity, receipt, partial-rejection handling, replay safety, correction/suppression/removal consequences, and public/API reconciliation.

No scheduled item may be counted as executed. Official-registration reviews recorded: 0. External-link checks executed: 0.
