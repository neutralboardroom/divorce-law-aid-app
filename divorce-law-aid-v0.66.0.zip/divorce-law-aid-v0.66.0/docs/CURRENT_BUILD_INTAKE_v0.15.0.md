# Current Build Intake Record — v0.15.0 mission

| Fact | Value | Evidence class |
|---|---|---|
| Assigned portal | Divorce Law Aid / `divorce-law-aid` | EXACT VERIFIED |
| Candidate base | `divorce-law-aid-v0.14.0.zip` | EXACT VERIFIED |
| Base SHA-256 | `7c684e6f4a8d0898b84db9e13e0e5b4cd1418a92587d22a75f2de8fbb7afcf27` | EXACT VERIFIED |
| Base size/root | 1,398,054 bytes / `divorce-law-aid-v0.14.0/` | EXACT VERIFIED |
| Base ZIP entries/files/directories | 535 / 353 / 182 | EXACT VERIFIED |
| Base runtime | Node 22.x; npm 10.x; zero runtime dependencies | EXACT VERIFIED |
| Baseline tests | 102 passed after clean extraction | EXACT VERIFIED |
| Base profiles | 162 total; 22 attorneys; 140 firms; all unclaimed | EXACT VERIFIED |
| Base deployment | Not deployed | EXACT VERIFIED |
| Smarter Justice reference | v1.7.46 portfolio record available in chat context; no dedicated exact handoff artifact supplied to this build | OWNER RECORDED |
| Supported contract | v1.4.0 read-only adapter | LOCALLY VERIFIED |
| Integration maturity | D3 candidate; D4/D5 unproven | EXACT VERIFIED |
| Rollback | exact v0.14.0 ZIP above | EXACT VERIFIED |

Open gates at intake: production integration, legal review, directory-wide official registration and broken-link rechecks, real-device and assistive-technology acceptance, support operations, deployment, payments, sponsorship, opportunities, confidential uploads, OCR, external AI, filing, service and signatures.
