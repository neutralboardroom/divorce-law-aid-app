# Current Build Intake — Divorce Law Aid v0.16.0

## Exact authoritative base

- Assigned portal: Divorce Law Aid / `divorce-law-aid` / DivorceLawAid.com.
- Base artifact: `divorce-law-aid-v0.15.0.zip` — EXACT VERIFIED.
- Base SHA-256: `c5edd8755147abd80fe16296ac17b855776839ae068bf967e134ad8767449102`.
- Base size: 1,524,160 bytes; 576 ZIP entries; 380 files; 196 directories.
- Base root: `divorce-law-aid-v0.15.0/`.
- Inventory: self-excluding `docs/source-manifest.sha256` with 379 records.
- Runtime: Node 22.x; zero runtime dependencies; lockfile present.
- Baseline reproduction: clean install passed, vulnerability audit reported 0, and 108 tests passed.
- Deployment: not deployed; production version and live imports unknown/not active.
- Rollback artifact: exact v0.15.0 above.

## Starting product counts

- 176 public profiles: 22 attorneys and 154 firms.
- 176 public unclaimed; 0 public claimed; 0 locally accepted central claim records.
- 0 approved attorney-firm relationships; 0 official registration reviews; 0 external link checks.
- 224 public HTML pages.

## Coordination truth

- Supported local contract: Smarter Justice professional handoff v1.4.0.
- Central artifact in this dedicated chat: owner-recorded only; no newer dedicated exact central handoff supplied for this build.
- Integration maturity: D3 local candidate; D4/D5 BLOCKED/UNPROVEN.
- Live claims, automatic publication, outreach delivery, payments, sponsorship and opportunities are closed.
