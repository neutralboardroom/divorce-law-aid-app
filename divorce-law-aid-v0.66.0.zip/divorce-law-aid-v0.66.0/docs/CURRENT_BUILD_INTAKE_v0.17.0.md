# Current Build Intake — Divorce Law Aid v0.17.0

## Exact authoritative base

- Base: `divorce-law-aid-v0.16.0.zip`
- Base SHA-256: `0e9657fac6b674aebdf24735e374e86ce752c9dfd4d6b199958f425288df389c`
- Base size: 1,652,343 bytes
- Base root: `divorce-law-aid-v0.16.0/`
- Evidence: EXACT VERIFIED in this dedicated chat.
- Rollback: the exact v0.16.0 ZIP above.

## Reproduced baseline

- Node 22.x; zero runtime dependencies.
- Clean install and zero-vulnerability audit passed.
- 114 baseline tests passed.
- 236 public HTML pages and 188 unclaimed public-information profiles.
- No deployment, live professional claims, live paid entitlements, live opportunities, live uploads, OCR, external AI, filing, signing, notarization, or outreach delivery.

## Current coordination truth

- Smarter Justice coordination remains the newest exact handoff already packaged with the portal and contract v1.4.0 compatibility.
- Portal-side adapter maturity remains D3 local acceptance only.
- D4 staging and D5 production are unproven.
