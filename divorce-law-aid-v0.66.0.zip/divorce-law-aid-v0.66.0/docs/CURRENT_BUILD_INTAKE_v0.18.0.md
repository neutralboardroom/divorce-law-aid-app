# Current Build Intake — Divorce Law Aid v0.18.0

## Exact base
- Assigned portal: Divorce Law Aid / DivorceLawAid.com.
- Authoritative base: `divorce-law-aid-v0.17.0.zip`.
- Base SHA-256: `d44ae7670a3fbedd2983a0cf808fc11431ae403b5eb3817c642a730fe2870f45`.
- Base size: 1,758,518 bytes.
- Base root: `divorce-law-aid-v0.17.0/`.
- Base entries: 706, including 489 files and 217 directories.
- Baseline reproduced: clean install, zero reported vulnerabilities, 122/122 tests, 249 public HTML pages and 197 public-information profiles.
- Rollback: exact v0.17.0 ZIP above.

## Coordination truth
- Supported portal handoff contract: v1.4.0, locally verified only.
- Current central exact artifact was not re-supplied in this chat; no newer central production compatibility is claimed.
- Smarter Justice integration maturity: D3 local candidate. D4 staging and D5 production are unproven.

## Starting profile truth
- 22 attorneys, 175 firms, 197 public profiles.
- All 197 unclaimed.
- Official registration reviews: 0.
- External link checks: 0.
- Approved attorney–firm relationships: 0.
- Live paid entitlements, allocations and deliveries: 0.

## Selected material scope
1. Unified browser-local review workspace and prepared-not-sent attorney review package.
2. Multi-item local document review with minimized optional persistence.
3. Time-limited, receipt-chained preliminary opportunity offer lifecycle while live gates remain closed.
4. Ten source-supported New York family-law firm profiles in Westchester, Dutchess and Orange Counties.
5. Full release-truth, testing, rollback and cross-portal documentation.
