# Current Build Intake Record — Divorce Law Aid v0.19.0

- Assigned portal: Divorce Law Aid / DivorceLawAid.com.
- Exact authoritative base: `divorce-law-aid-v0.18.0.zip`.
- Base SHA-256: `2087713b05d6864209d63d2e0e4ffe0cb0ae3a79dcde2fc9d35af5955bbb583c`.
- Base exact size: 1,823,071 bytes.
- Base root: `divorce-law-aid-v0.18.0/`; 743 entries, 516 files, 227 directories.
- Base manifest: 515 self-excluding records; SHA-256 `ea425148369bedb484a900fdcdcabc219dac7229f1d557e62db41a5e8048b1dd`.
- Runtime: Node 22.x, npm lockfile v3, zero runtime dependencies.
- Reproduced baseline: clean install, 0 reported vulnerabilities, 129 tests passed, application audit passed.
- Baseline public truth: 260 HTML pages; 207 profiles; 22 attorneys; 185 firms; 207 unclaimed; 0 claimed.
- Deployment: not deployed. Production version unknown/not active.
- Smarter Justice coordination: locally verified read-only v1.4.0 consumer and protected signed handoff, D3 candidate only. No exact D4 staging or D5 production evidence was available in this portal chat.
- Open gates: central accounts/claims, payments, live membership projection, opportunity delivery, confidential release, outreach delivery, server uploads, OCR, external AI, filing, service, signatures, notarization, broad launch.
- Rollback: exact v0.18.0 ZIP above.
- Controlling instruction: complete-product-capabilities master prompt, exact uploaded file SHA-256 `8451aaf772bd2bbc6abcebdd8871dfb53cb30e6e69b0df24c4547fd8d9a64a53`, 219,588 bytes.

Evidence classification: artifact and reproduced test facts are EXACT VERIFIED; Smarter Justice D3 behavior is locally verified; deployment, D4/D5, legal approval and live operations are BLOCKED or UNKNOWN.
