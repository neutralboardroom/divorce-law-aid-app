# Current Build Intake — v0.20.0

- Assigned portal: Divorce Law Aid (`divorce-law-aid`).
- Exact authoritative base: `divorce-law-aid-v0.19.0.zip`, SHA-256 `4cc1d8cf05e22b9ed7daaad94659a88a7772918d45dc829e3eabb4ba784815ea`, 1,898,388 bytes.
- Baseline reproduced: 136 tests passed; zero runtime dependencies; npm audit reported zero vulnerabilities.
- Baseline inventory: 217 profiles, 271 public HTML pages, not deployed, all sensitive and commercial gates closed.
- Rollback: untouched v0.19.0 extraction and exact ZIP.
- Smarter Justice: local read-only v1.4.0 D3 candidate only; D4/D5 unproven.
- Assigned-scope rule: the four-portal instruction applies shared standards to this repository; Domestic Violence Aid and Stop Sign Project behavior was not copied into Divorce Law Aid.
