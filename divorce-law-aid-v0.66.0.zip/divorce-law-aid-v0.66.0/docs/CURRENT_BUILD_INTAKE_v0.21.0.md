# Current Build Intake — v0.21.0

- Assigned portal: Divorce Law Aid (`divorce-law-aid`).
- Exact authoritative base: `divorce-law-aid-v0.20.0.zip`, SHA-256 `d9e8285902278b88b0a7a9a59a93470e98ceb30acd3033cafb450093ad39821b`, 1,995,489 bytes.
- Base repository root: `divorce-law-aid-v0.20.0/`; 574 files, 247 explicit directories and 821 ZIP entries.
- Baseline reproduced: 143 tests passed; zero runtime dependencies; npm audit reported zero vulnerabilities.
- Baseline inventory: 227 profiles (22 attorneys and 205 firms), 282 public HTML pages, not deployed, all sensitive and commercial gates closed.
- Corrective owner direction: resume the build while making individual-attorney growth the primary profile workstream.
- Rollback: untouched v0.20.0 extraction and exact ZIP.
- Smarter Justice: local read-only v1.4.0 D3 candidate only; D4/D5 unproven.
- Four-portal scope: shared requirements apply; Domestic Violence Aid survivor-safety, organization-profile and Stop Sign Project behavior remains outside this repository.
