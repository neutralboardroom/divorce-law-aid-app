# Current Build Intake — v0.22.0

- Assigned portal: Divorce Law Aid (`divorce-law-aid`)
- Exact authoritative base: `divorce-law-aid-v0.21.0.zip`
- Base SHA-256: `38a03a13cac44ae5f79115ddcd55ab744d3b97dfcde2b0db59297d7cbdd07a33`
- Base size: 2,082,912 bytes; 603 files; 259 directories; root `divorce-law-aid-v0.21.0/`
- Baseline: 150 tests, zero runtime dependencies, 239 profiles (34 attorneys, 205 firms), not deployed.
- Release priority: continue the owner-directed attorney-first correction.
- Smarter Justice: owner-recorded coordination reference; portal handoff remains locally verified D3 only.
- Open gates: live accounts/claims, official registration completion, payments, confidential upload/release, outreach, opportunity delivery, D4 staging and D5 production.
- Rollback: exact v0.21.0 artifact above.
