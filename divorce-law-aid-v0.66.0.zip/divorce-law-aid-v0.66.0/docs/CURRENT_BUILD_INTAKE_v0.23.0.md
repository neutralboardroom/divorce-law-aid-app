# Current Build Intake — v0.23.0

- Assigned portal: Divorce Law Aid / `divorce-law-aid`.
- Exact base: `divorce-law-aid-v0.22.0.zip`.
- Base SHA-256: `094e1a0c7caea90265e0cecfd3ad5044320596ea7ddc76f9edae987cfd6f4333`.
- Base size: 2,228,140 bytes.
- Base ZIP: 926 entries; 642 files; 284 explicit directories; root `divorce-law-aid-v0.22.0/`.
- Base manifest: 641 self-excluding records; SHA-256 `ced86271bf28396e1f54b85fc6549560adbeeaca49e4f1531c9e3ab2a89b00da`.
- Runtime: Node 22.x; zero runtime dependencies; lockfile present.
- Reproduced baseline: clean install, 0 vulnerabilities, 157 tests and application audit passed.
- Starting counts: 264 profiles; 59 attorneys; 205 firms; 37 approved relationships; all unclaimed.
- Deployment truth: not deployed; D3 local Smarter Justice candidate only.
- Open gates: legal review, D4/D5, real-device/accessibility, production accounts/auth/MFA, registration/link checks, payments, outreach, server upload/OCR/AI, confidential release and opportunity delivery.
- Rollback: untouched exact v0.22.0 extraction and ZIP.
