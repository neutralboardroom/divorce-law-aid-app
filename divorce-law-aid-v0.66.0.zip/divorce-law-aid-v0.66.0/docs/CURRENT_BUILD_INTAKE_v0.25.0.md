# Current Build Intake — Divorce Law Aid v0.25.0

- Assigned portal: Divorce Law Aid / DivorceLawAid.com.
- Exact authoritative base: `divorce-law-aid-v0.24.0.zip`.
- Base SHA-256: `51450a1b634a27f3919f910090db5454ac639449e076b2ccd93734ee0e1a8987`.
- Base size: 2,592,472 bytes; 1,052 entries; 722 files; 330 directories; one `divorce-law-aid-v0.24.0/` root.
- Base manifest: 721 self-excluding records; SHA-256 `54a472eb4acd45a435a64ae79bc411c5ad4ce4032364f2eb1508dcb0e40e9051`.
- Reproduced baseline: 175 tests, zero reported vulnerabilities, 367 public pages, 310 profiles (103 attorneys and 207 firms), 81 approved relationships.
- Runtime: Node 22.x; zero runtime dependencies.
- Deployment: not deployed; production version unknown.
- Smarter Justice: local D3 candidate only; D4 staging and D5 production unproven.
- Rollback: exact v0.24.0 ZIP and untouched extraction preserved.
- Release type: focused material release.
- Selected scope: attorney-first profile growth plus a prepared-not-sent professional follow-up continuation journey.
