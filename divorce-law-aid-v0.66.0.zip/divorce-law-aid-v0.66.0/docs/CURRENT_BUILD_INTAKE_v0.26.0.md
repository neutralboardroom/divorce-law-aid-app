# Current Build Intake — Divorce Law Aid v0.26.0

- Authoritative base: `divorce-law-aid-v0.25.0.zip`.
- Base SHA-256: `588e555adfef91055a067406a1dbaddfd3d63c21173684da9487336d39f738c1`.
- Base size: 2,676,570 bytes; 1,113 ZIP entries; 760 files; 353 directories; one repository root.
- Baseline reproduced: 182 tests and zero reported vulnerabilities.
- Baseline product truth: 333 profiles, 126 attorneys, 207 firms, 104 approved relationships and 391 public HTML pages.
- Active public language at intake: English; no explicit versioned language-control contract was present.
- Deployment: not deployed. Smarter Justice D3 local candidate only; D4/D5 unproven.
- Rollback: exact v0.25.0 ZIP above.
