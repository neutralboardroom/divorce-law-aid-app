# Current Build Intake — Divorce Law Aid v0.27.0

- Authoritative base: `divorce-law-aid-v0.26.0.zip`.
- Base SHA-256: `de8130b7b208b60c14c0876b655b1661a39c483da272f7453f98a01d31e3818b`.
- Base exact size: 2,885,267 bytes.
- Base root: `divorce-law-aid-v0.26.0/`.
- Current build root: `divorce-law-aid-v0.27.0/`.
- Mission: reconcile current release truth, authority, rollback, NVIL and exact-release evidence without weakening the public product or opening unsupported gates.
- Baseline reproduced: clean install, zero reported vulnerabilities, 189/189 tests, build and application audit.
- Browser baseline reproduction: blocked by administrator policy; prior artifact browser acceptance retained only as artifact-carried evidence.
