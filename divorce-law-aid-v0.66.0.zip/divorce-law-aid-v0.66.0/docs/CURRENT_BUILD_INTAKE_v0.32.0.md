# Current Build Intake — Divorce Law Aid v0.32.0

- Active mode: Mode A, Divorce Law Aid repository only.
- Controlling prompt: exact sixteenth pass, SHA-256 `6977a040eddc4e8005480129cc71756f037d262b894299e534b567413ca95018`, 440,590 bytes, 10,079 lines.
- Exact base: `divorce-law-aid-v0.30.0.zip`, SHA-256 `ee3983d01556c1c4c932d03c9cef3a7ef277c2d7d83172cc749b491a64db2f2c`, 3,334,694 bytes, 1,252 entries, 882 files, 370 directories.
- Baseline reproduced: Node v22.16.0, npm 10.9.2, zero vulnerabilities, 244 tests, build, application audit, launch control, current truth, D0–D5, suppression, and evidence validation.
- Selected release: complete connected Tier A deployment-readiness release.
- Current public truth: 409 HTML pages, 412 routes/endpoints, 350 profiles, 143 attorneys, 207 firms, 121 relationships, English only.
- Current gates: no owner approval, no deployment, no post-deployment verification, no live acceptance; D0 professional central paths; all commercial and sensitive gates closed.
- Rollback: exact v0.30.0 predecessor above.
