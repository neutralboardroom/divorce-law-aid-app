# Current Build Intake — Divorce Law Aid v0.33.0

- Active mode: MODE A.
- Base: `divorce-law-aid-v0.32.0.zip`.
- Base SHA-256: `7b33c2df537f294394561fe1ef57fe7d67fa348074e5973a2beae01f9395433a`.
- Base size: 3,435,354 bytes.
- Base root: `divorce-law-aid-v0.32.0/`.
- Base ZIP: 1,309 entries; 939 files; 370 directories.
- Runtime: Node v22.16.0; npm 10.9.2; zero runtime dependencies.
- Baseline: clean install, 0 vulnerabilities, 265 tests, build/audit/control validators passed.
- Controlling prompt: twentieth pass, SHA-256 `a666f7f5b32e2da6cc1561bfd900c75d11ad6a1e4645793413e83c3ab318c418`, 493,156 bytes, 10,958 lines.
- Release classification: COMPLETE CONNECTED MATERIAL RELEASE.
- Selected scope: Monday demonstration, memory-first/Matter Path, public freemium, exact $15 central-commercial presentation, future high-cost safeguards, launch/evidence continuity.
- Current truth: 410 HTML; 413 routes; 350 profiles; 143 attorneys; 207 firms; 121 relationships; 61 sources; 964 tasks; 281 tests.
- Language: English active; alternate languages inactive.
- Integration: D0; no exact current central contract supplied.
- Deployment/live: none.
- Rollback: exact v0.32.0 only.
