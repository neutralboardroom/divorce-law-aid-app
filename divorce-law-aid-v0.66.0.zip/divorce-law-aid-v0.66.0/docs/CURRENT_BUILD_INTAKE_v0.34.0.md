# Current Build Intake — Divorce Law Aid v0.34.0

- Active mode: MODE A.
- Base: `divorce-law-aid-v0.33.0.zip`.
- Base SHA-256: `6a28fa9328f66cb8b36c1cbf9f849ceca8afcb0eb67c3e503ad5537598ba5f8f`.
- Base size: 3,682,855 bytes.
- Base root: `divorce-law-aid-v0.33.0/`.
- Base ZIP: 1,352 entries; 981 files; 371 directories.
- Runtime: Node v22.16.0; npm 10.9.2; zero runtime dependencies.
- Baseline: clean install, 0 vulnerabilities, 281 tests, deterministic build, audit, launch, human-acceptance, evidence, checkpoint, suppression, and D0–D5 validators passed.
- Controlling prompt: twenty-first pass, SHA-256 `587556cabb09c2ba0994d3d772c8546d110cf503375791ae04f9d71991edc47b`, 504,137 bytes, 11,130 lines.
- Release classification: COMPLETE CONNECTED MATERIAL RELEASE.
- Selected scope: binding public free-core nonregression, USD commercial-manifest discipline, CLAIMED/MEMBER separation, covered-seat payer-transfer safeguards, and human attorney-demonstration acceptance control.
- Current source truth: 410 HTML pages; 413 routes; 350 profiles; 143 attorneys; 207 firms; 121 relationships; 61 sources; 964 tasks; 297 tests.
- Language: English active; alternate languages inactive.
- Integration: D0; no exact current central Commercial Terms and Entitlement Manifest or producer contract supplied.
- Deployment/live: none.
- Rollback: exact v0.33.0 only.
