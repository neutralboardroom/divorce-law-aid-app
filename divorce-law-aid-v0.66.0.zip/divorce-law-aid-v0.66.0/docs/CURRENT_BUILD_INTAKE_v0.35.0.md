# Current Build Intake — Divorce Law Aid v0.35.0

- Active mode: MODE A.
- Base: `divorce-law-aid-v0.34.0.zip`.
- Base SHA-256: `f5bf85408e69f25fc34a40b4e71b3db737c8bb2a0bdede5a98e3b67a64cffce3`.
- Base size: 3,922,044 bytes.
- Base root: `divorce-law-aid-v0.34.0/`.
- Base ZIP: 1,393 entries; 1,022 files; 371 directories.
- Runtime: Node v22.16.0; npm 10.9.2; zero runtime dependencies.
- Baseline: clean install, 0 vulnerabilities, 297 tests, application audit, commercial/Monday/deployment/human/launch/current-truth/D0–D5/suppression/evidence/checkpoint/manifest controls passed.
- Controlling prompt: twenty-first pass, SHA-256 `587556cabb09c2ba0994d3d772c8546d110cf503375791ae04f9d71991edc47b`, 504,137 bytes, 11,130 lines.
- Release classification: P0 REMEDIATION RELEASE.
- Selected scope: ordinary-build idempotence, frozen release clock, explicit operational currentness refresh, full fresh-extraction pre/post-build source equality, stable source manifest, and corrected v0.33.0 migration regression.
- Preserved source truth: 410 HTML pages; 413 routes; 350 profiles; 143 attorneys; 207 firms; 121 relationships; 61 sources; 964 tasks.
- Declared regression after remediation: 309 tests.
- Language: English active; alternate languages inactive.
- Integration: D0; no exact current central producer contract supplied.
- Deployment/live: none.
- Rollback: exact v0.34.0 only.
