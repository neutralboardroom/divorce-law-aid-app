# Current Build Intake — Divorce Law Aid v0.36.0

- Active mode: MODE A.
- Base: `divorce-law-aid-v0.35.0.zip`.
- Base SHA-256: `288cb118ef361fc3a20d1e2966654fbdb4b67d5d7f77e636269ad4d9c5a67d1a`.
- Base size: 3,999,447 bytes.
- Base root: `divorce-law-aid-v0.35.0/`.
- Base ZIP: 1,438 entries; 1,067 files; 371 directories.
- Runtime: Node v22.16.0; npm 10.9.2; zero runtime dependencies.
- Baseline: clean install, 0 vulnerabilities, 309 tests, byte-idempotent build, stable source manifest, application audit, commercial/Monday/deployment/human/launch/current-truth/D0–D5/suppression/13-group evidence/checkpoint/manifest controls passed.
- Controlling prompt: twenty-first pass, SHA-256 `587556cabb09c2ba0994d3d772c8546d110cf503375791ae04f9d71991edc47b`, 504,137 bytes, 11,130 lines.
- Release classification: P0 REMEDIATION RELEASE.
- Selected scope: deterministic synthetic opportunity-allocation and lifecycle evidence, explicit clocks, byte-identical repeated outputs, receipt-chain integrity, and fresh-extraction proof.
- Preserved source truth: 410 HTML pages; 413 routes; 350 profiles; 143 attorneys; 207 firms; 121 relationships; 61 sources; 964 tasks.
- Declared regression after remediation: 321 tests.
- Language: English active; alternate languages inactive.
- Integration: D0; no exact current central producer contract supplied.
- Deployment/live: none.
- Rollback: exact v0.35.0 only.
