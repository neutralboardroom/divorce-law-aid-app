# Current Build Intake — Divorce Law Aid v0.40.0

- Mode: A — dedicated Divorce Law Aid builder.
- Controlling prompt: exact twenty-third pass, SHA-256 `44d73f09e3316d6308323912712ea355a3985085cfa71ba699dfaad1ab01be88`, 573,747 bytes, 12,362 lines.
- Durable-rule baseline: `DRB-2026-07-31-DUR001-DUR043-V2`; semantic-capsule SHA-256 `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`.
- Base: `divorce-law-aid-v0.39.0.zip`.
- Base SHA-256: `67d4f0e47e8eb57af1a743e2e15e1d440bed9f0dafa96a6d161896799789ab96`.
- Base exact size: 4,323,761 bytes.
- Selected scope: material governance, currentness, public-truth and repeatability release, including official 2026 New York joint-divorce guidance.
- No deployment, payment, D4/D5, human acceptance, or live acceptance is claimed.
