# Current Build Intake — Divorce Law Aid v0.41.0

- Mode: A — dedicated Divorce Law Aid builder.
- Controlling prompt: exact twenty-fifth pass, SHA-256 `1d4d528fbeae3e4c7da6b1ccb92f10f9bb8e2da9fe6debe81a71db1e39674372`, 592,992 bytes, 12,678 lines.
- Durable-rule baseline: `DRB-2026-07-31-DUR001-DUR043-V2`; semantic-capsule SHA-256 `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`.
- Base: `divorce-law-aid-v0.40.0.zip`.
- Base SHA-256: `2fbb5d785ce7fdd39e6c190fe5ed4fac8fb3a913fd9a8c8dc0c5afcc3dc8c6b1`.
- Base exact size: 4,629,555 bytes.
- Selected scope: last-known-compatible dual-master pair preservation, two-phase propagation prepare/validate/commit/abort/rollback, reciprocal-authority gating, portal-continuation binding, and current research/public-language/repeatability revalidation.
- No reciprocal central propagation, D1–D5, deployment, payment, human acceptance, or live acceptance is claimed.
