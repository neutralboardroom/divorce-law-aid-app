# Current Build Intake — Divorce Law Aid v0.42.0

- Mode: A — dedicated Divorce Law Aid builder.
- Controlling prompt: exact twenty-sixth pass, SHA-256 `fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f`, 592,992 bytes, 12,678 lines.
- Durable-rule baseline: `DRB-2026-07-31-DUR001-DUR043-V2`; semantic-capsule SHA-256 `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`.
- Base: `divorce-law-aid-v0.41.0.zip`.
- Base SHA-256: `3493e0c8c5dcebbf9bad1b958bd77fb4b9dab3d90be532aa86900e0c1e3a7ce1`.
- Base exact size: 4,950,098 bytes.
- Selected scope: last-known-compatible dual-master pair preservation, two-phase propagation prepare/validate/commit/abort/rollback, reciprocal-authority gating, portal-continuation binding, and current research/public-language/repeatability revalidation.
- No reciprocal central propagation, D1–D5, deployment, payment, human acceptance, or live acceptance is claimed.
