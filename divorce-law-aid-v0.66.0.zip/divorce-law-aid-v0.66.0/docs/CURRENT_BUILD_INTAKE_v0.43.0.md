# Current Build Intake — Divorce Law Aid v0.43.0

- Mode: A — dedicated Divorce Law Aid builder.
- Controlling prompt transport filename: `Four_Initial_Legal_Micro_Portals_Reusable_Master_Build_Prompt_Twenty_Sixth_Pass_Prompt_Self_Identity_Binding_Current_Pass_Marker_Derivation_Stale_Marker_Regression_2026-07-31(4).txt`.
- Packaged prompt: `docs/CURRENT_BUILD_MASTER_INSTRUCTION_TWENTY_SIXTH_PASS.txt`.
- Prompt SHA-256: `fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f`; 599,027 bytes; 12,776 lines.
- Exact immutable parent SHA-256: `1d4d528fbeae3e4c7da6b1ccb92f10f9bb8e2da9fe6debe81a71db1e39674372`; 592,992 bytes; 12,678 lines.
- Durable-rule baseline: `DRB-2026-07-31-DUR001-DUR043-V2`; semantic-capsule SHA-256 `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`.
- Base: `divorce-law-aid-v0.42.0.zip`.
- Base SHA-256: `362f458add67f99b53d43db702aae7de6b24a2d9ebdb7183a7e12885a4a13acb`.
- Base exact size: 5,266,950 bytes.
- Selected scope: full-context stale-marker containment, transport-alias verification, precise master-prompt correction proposal, browser-local migration continuity, and revalidation of all inherited controls.
- No reciprocal central propagation, D1–D5, deployment, payment, human acceptance, or live acceptance is claimed.
