# Current Build Intake — Divorce Law Aid v0.44.0

- Mode: A — dedicated Divorce Law Aid builder.
- Controlling prompt transport filename: `Four_Initial_Legal_Micro_Portals_Reusable_Master_Build_Prompt_Twenty_Sixth_Pass_Prompt_Self_Identity_Binding_Current_Pass_Marker_Derivation_Stale_Marker_Regression_2026-07-31(6).txt`.
- Packaged prompt: `docs/CURRENT_BUILD_MASTER_INSTRUCTION_TWENTY_SIXTH_PASS.txt`.
- Prompt SHA-256: `fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f`; 599,027 bytes; 12,776 lines.
- Exact immutable parent SHA-256: `1d4d528fbeae3e4c7da6b1ccb92f10f9bb8e2da9fe6debe81a71db1e39674372`; 592,992 bytes; 12,678 lines.
- Durable-rule baseline: `DRB-2026-07-31-DUR001-DUR043-V2`; semantic-capsule SHA-256 `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`.
- Base: `divorce-law-aid-v0.43.0.zip`.
- Base SHA-256: `6da0186a4f0aca90a7d3cb5239de1deb3338870874d13e51d889b7da37e53efd`.
- Base exact size: 5,396,585 bytes.
- Selected scope: append-only prompt transport-alias lineage for the byte-identical (2), (4), and current (6) observations, conflict detection, preservation of the four contained stale markers and correction proposal, v0.43.0 browser-local migration continuity, and revalidation of all inherited controls.
- No reciprocal central propagation, D1–D5, deployment, payment, human acceptance, or live acceptance is claimed.
