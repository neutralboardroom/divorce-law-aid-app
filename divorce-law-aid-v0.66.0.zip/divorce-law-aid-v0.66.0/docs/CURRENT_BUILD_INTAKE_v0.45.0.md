# Current Build Intake — Divorce Law Aid v0.45.0

## Authoritative base

- `divorce-law-aid-v0.44.0.zip`
- SHA-256 `cf31642a4f98233d2de179944c940aa02fc29f0189347102ef66c313a2e43391`
- Exact size `5528009` bytes

## Current coordinated authority

- Pack `UNIVERSAL_SMARTER_JUSTICE_AND_ALL_LEGAL_MICRO_PORTALS__TWO_UPLOAD_AUTOSTART_BUILDER_PACKET__REFINED_V3__ALL_DURABLE_RULES__PACK_SJP-2026-08-02-C15-P37-D11-V13.zip`
- Pack ID `SJP-2026-08-02-C15-P37-D11-V13`
- SHA-256 `66d90dfef66be8484fa43b07657a01b117e72989534e63a1e764d6f8b7760d78`
- Exact size `475763` bytes
- Durable baseline `DRB-2026-08-02-DUR001-DUR086-V13`
- Active rows: 86 master + 20 owner supplemental + 20 builder supplemental = 126

The historical twenty-sixth-pass prompt remains packaged only for exact lineage and compatibility evidence. It does not override the coordinated V3 authority for v0.45.0.
