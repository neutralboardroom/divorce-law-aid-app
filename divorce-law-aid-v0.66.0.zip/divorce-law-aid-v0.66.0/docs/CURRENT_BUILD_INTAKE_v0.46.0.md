# Current Build Intake — Divorce Law Aid v0.46.0

## Authoritative base

- `divorce-law-aid-v0.45.0.zip`
- SHA-256 `2eea5174bd830d0433bbbeca05193ac8828fc59b48dfabf860cce74edf91523b`
- Exact size `6639829` bytes

## Current coordinated authority

- Pack `UNIVERSAL_SMARTER_JUSTICE_AND_ALL_LEGAL_MICRO_PORTALS__ONE_STEP_BUILDER__REFINED_V7__RULE_SUCCESSORSHIP_AND_FAST_PRODUCT_READINESS__ALL_DURABLE_RULES__PACK_SJP-2026-08-02-C15-P37-D11-V13.zip`
- Pack ID `SJP-2026-08-02-C15-P37-D11-V13`
- SHA-256 `80ae674c6fb932fc9e675052821753168d1c385bfb2c12d41113739c357f9245`
- Exact size `506375` bytes
- Durable baseline `DRB-2026-08-02-DUR001-DUR086-V13`
- Shared rows: 86 master + 36 owner supplemental + 36 builder supplemental = 158
- Global successorship: `ODR-010`, `ODR-021`, and `BDR-021` are inherited superseded tombstones.
- Conditional applicability: `ODR-012`, `BDR-019`, `BDR-022`, and `BDR-023` are condition-not-triggered for this release.

The historical V3 packet and twenty-sixth-pass prompt remain packaged only for exact lineage and compatibility evidence. They do not override V7 current authority for v0.46.0.
