# Current Build Intake — Divorce Law Aid v0.64.0

## Authoritative base

- `divorce-law-aid-v0.64.0.zip`
- SHA-256 `dd34cc1b4ac683c68bec157435c04c25a9fc0e50ab3271ffe0e7f1467292dd7f`
- Exact size `11051071` bytes

## Current coordinated authority

- Pack `UNIVERSAL_SMARTER_JUSTICE_AND_ALL_LEGAL_MICRO_PORTALS__ONE_STEP_BUILDER__REFINED_V9__BALANCED_MATERIAL_RELEASES_AND_EVIDENCE__ALL_DURABLE_RULES__PACK_SJP-2026-08-02-C15-P37-D11-V13.zip`
- Pack ID `SJP-2026-08-02-C15-P37-D11-V13`
- SHA-256 `37d90cab818b71613c388bf195b08d129eb569dd183de5358f32dd335975a1d5`
- Exact size `514368` bytes
- Durable baseline `DRB-2026-08-02-DUR001-DUR086-V13`
- Shared rows: 86 master + 36 owner supplemental + 36 builder supplemental = 170
- Global successorship: `ODR-010`, `ODR-021`, and `BDR-021` are inherited superseded tombstones.
- Conditional applicability: `ODR-012`, `BDR-019`, `BDR-022`, and `BDR-023` are condition-not-triggered for this release.

The historical V3 packet and twenty-sixth-pass prompt remain packaged only for exact lineage and compatibility evidence. They do not override V7 current authority for v0.64.0.
