# Data Schema and Separation Rules

No production database is active. Current user-entered organizer work is stored only in the user's browser or tab. Repository JSON contains non-confidential public-source records, synthetic test fixtures, and internal build-governance records.

A future approved database should keep separate records for accounts, roles, matters, parties, children, parenting plans, assets, debts, income, expenses, support, documents, versions, uploads, deadlines, tasks, professionals, firms, credentials, claims, memberships, contact requests, conflicts, engagements, payments, refunds, referrals, permissions, incidents, and immutable audit events.

Required separations include:

- user statement versus document evidence;
- allegation versus court finding;
- proposal versus signed agreement versus entered order;
- profile versus profile claim;
- credential evidence versus paid membership or sponsorship;
- profile view versus contact request;
- contact request versus conflict check;
- conflict check versus engagement and representation;
- self-help payment versus professional fee;
- draft versus filing;
- submission versus court acceptance;
- signature versus binding effect or court order.

Any future schema requires versioned migrations, constraints, transactions, idempotency, concurrency control, retention, deletion, backup, restore, and rollback testing.

## v0.14.0 local profile-operation records

The local development artifact adds separate non-public records for profile review evidence and attorney-firm relationship proposals. Review records separate practice-source status, official-registration status and external-link result. Relationship records remain pending until an explicit decision and update attorney/firm directions together only after approval. Reviewer identity, notes, private official identifiers and audit details are operator data and are not part of the public API projection.

The consultation packet does not create a repository or server record. It reads the existing browser-local plan on user command and renders a temporary page preview.

## v0.15.0 real profile-growth records

`data/profile-batches-v0.15.0.json` is one immutable reviewed batch with an exact digest. Accepted public records preserve candidate ID, batch ID, source ID, specialty evidence and publication review in provenance. Public address, phone and email are carried only when the reviewed candidate supplies them. `directory-coverage.json` is generated from merged public profiles and review ledgers.
