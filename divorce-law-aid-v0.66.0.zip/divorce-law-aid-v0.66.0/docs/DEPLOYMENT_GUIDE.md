# Deployment Guide — Divorce Law Aid v0.66.0

Deploy only an exact-tested `divorce-law-aid-v0.66.0.zip` candidate. Bind staging and production receipts to its final SHA-256, immutable deployment ID, release-candidate ID, runtime configuration, route inventory, and rollback target.

Exact rollback target: `divorce-law-aid-v0.65.0.zip`, SHA-256 `6738274b5ddc4a4409da3e8f23db3ce8256aa575c60e87006b281e83055a55aa`, size `18206516` bytes.

Owner approval, deployment, post-deployment verification, and live acceptance are separate states. None is established by the source build alone. Use the packaged Dockerfile or Procfile, keep secrets in the provider secret manager, run `npm run deployment:smoke`, and preserve the generated nonsecret receipt.


## Optional central AI gateway adapter — dark by default

Divorce Law Aid never stores `OPENAI_API_KEY` and does not call OpenAI directly. The optional portal adapter expects only an exact Smarter Justice central-gateway URL and a narrow server-to-server `SJ_AI_GATEWAY_TOKEN`. Keep `DLA_AI_ENABLED=false`, `DLA_AI_TOOL_DIVORCE_PREPARATION_SUMMARY_ENABLED=false`, and `AI_GLOBAL_KILL_SWITCH=true` until the exact central compatibility receipt, deployment identity, controlled live smoke, monitoring, cost hard stop, and rollback evidence pass. CI uses synthetic fixtures and makes zero production OpenAI calls.
