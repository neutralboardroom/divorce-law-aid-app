# Deterministic build and release-clock policy — v0.61.0

State: **DETERMINISTIC BUILD CLOCK AND IDEMPOTENCE CONTROLS PREPARED**

- Frozen release clock: `2026-08-03T19:45:00-04:00` (`2026-08-03T23:45:00.000Z`).
- SOURCE_DATE_EPOCH: `1785800700`.
- Rebuilding an accepted source release must not advance generated timestamps or change any packaged file.
- Use an explicit `--as-of` value for a new operational currentness review; that review is new evidence, not an ordinary rebuild side effect.
- `npm run build` repeats the deterministic generation pipeline and fails if any packaged file changes.
- The fresh-extraction artifact test independently compares the source tree before and after the build.
