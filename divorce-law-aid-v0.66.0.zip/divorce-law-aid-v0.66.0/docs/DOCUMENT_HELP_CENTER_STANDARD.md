# Document Help Center Standard

The portal separates six user intentions: review a document or screenshot; compare two text versions; create an attorney-review discussion draft; use guided forms and checklists; locate official court forms and instructions; and build a selective prepared-not-sent attorney-review package.

Official forms, portal preparation materials, document review, drafting, attorney review, and filing are distinct. Electronic filing, service, signing, notarization, court acceptance, cloud upload, OCR, external AI, and automatic attorney sharing are not provided.
