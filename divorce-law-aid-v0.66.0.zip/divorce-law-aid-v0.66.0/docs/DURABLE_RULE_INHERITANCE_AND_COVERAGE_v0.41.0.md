# Durable Rule Inheritance and Coverage — v0.41.0

- Baseline: `DRB-2026-07-31-DUR001-DUR043-V2`
- Ordered active rules: DUR-001 through DUR-043
- Semantic capsule SHA-256: `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`
- Prompt SHA-256: `1d4d528fbeae3e4c7da6b1ccb92f10f9bb8e2da9fe6debe81a71db1e39674372`
- Inheritance state: **BASELINE MATCHED**
- Exceptions: none
- Lineage conflicts: none
- Local rule-semantic changes: none

The 43-row machine-readable matrix records product-specific implementation and evidence truth. Prompt inheritance does not claim staging, deployment, billing, human acceptance, or live operation.
