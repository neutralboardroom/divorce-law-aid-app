# Durable Rule Inheritance and Coverage — v0.42.0

- Baseline: `DRB-2026-07-31-DUR001-DUR043-V2`
- Ordered active rules: DUR-001 through DUR-043
- Semantic capsule SHA-256: `3d5f7cc4b33980148510834f6b23f902fb5416dbdc9398f106a3b14e81713bf8`
- Prompt SHA-256: `fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00930e6d4573f`
- Inheritance state: **BASELINE MATCHED**
- Exceptions: none
- Lineage conflicts: none
- Local rule-semantic changes: none

The 43-row machine-readable matrix records product-specific implementation and evidence truth. Prompt inheritance does not claim staging, deployment, billing, human acceptance, or live operation.
