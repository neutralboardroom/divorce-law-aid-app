# Durable Rule Inheritance and Coverage — v0.45.0

- Current baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Current pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Coverage: 86 master + 20 owner supplemental + 20 builder supplemental = 126 active rows.
- Exact durable-register SHA-256: `4259cc1b31d75546a553b3ec9edafffcb715051b5a15b342ec592806d73903df`
- Prior 43-rule baseline remains the immediate historical parent; no prior rule is deleted or semantically rewritten.
- Product implementation, deployment, external activation, canonical central commit and live acceptance remain separately evidenced.
