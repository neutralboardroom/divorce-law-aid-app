# Durable Rule Inheritance and Coverage — v0.49.0

- Baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Current pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Coverage: 86 master + 36 owner + 36 builder = 158 shared rows.
- Superseded tombstones: ODR-010, ODR-021, BDR-021.
- Conditional, not triggered here: ODR-012, BDR-019, BDR-022, BDR-023.
- Exact V7 durable-register SHA-256: `3c99ef3e5aef8bdaf1a125c2f1eaad52848c9a8a75d668d65ede9c3d989800bf`.
- Product applicability and readiness are separately machine-validated; portfolio aggregation remains central.
