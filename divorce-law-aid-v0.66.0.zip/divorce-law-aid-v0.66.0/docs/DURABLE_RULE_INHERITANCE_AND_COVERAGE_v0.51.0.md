# Durable Rule Inheritance and Coverage — v0.51.0

- Baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Current pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Coverage: 86 master + 42 owner + 42 builder = 170 shared rows.
- Superseded tombstones: ODR-010, ODR-021, BDR-021.
- Conditional, not triggered here: ODR-012, BDR-019, BDR-022, BDR-023.
- Exact V8 durable-register SHA-256: `0da9623cddebcad0ea791296995339a738268b4469e5ed6703e4f2df67174682`.
- Product applicability and readiness are separately machine-validated; portfolio aggregation remains central.
