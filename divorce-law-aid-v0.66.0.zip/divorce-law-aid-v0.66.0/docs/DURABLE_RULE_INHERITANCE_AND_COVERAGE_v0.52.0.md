# Durable Rule Inheritance and Coverage — v0.52.0

- Baseline: `DRB-2026-08-02-DUR001-DUR086-V13`
- Current pack: `SJP-2026-08-02-C15-P37-D11-V13`
- Coverage: 86 master + 43 owner + 43 builder = 172 shared rows.
- Superseded tombstones: ODR-010, ODR-021, BDR-021.
- Conditional, not triggered here: ODR-012, BDR-019, BDR-022, BDR-023.
- Exact V9 durable-register SHA-256: `1ebeab8d43119166243f88603da738d6acd7b7a38806ead206d4be0ee7ba6cfc`.
- Product applicability and readiness are separately machine-validated; portfolio aggregation remains central.
