# Durable Rule Inheritance and Coverage — v0.59.0

- Coverage: 86 master + 70 owner + 70 builder = 226 shared rows.
- Exact V12 durable-register SHA-256: `05c3fff9041628b34346dee20af3a8c55aa2adbfb319351c7312ad2adb37d21c`.
- Continuous product and prompt self-improvement is mandatory.
