# English-First Language Control Standard — v0.27.0

- Active public interface language: English (`en`).
- Current phase: `ENGLISH_BUILD`.
- Spanish and every additional-language feature flag: off.
- No active alternate-language navigation, route, sitemap entry, canonical alternate or `hreflang` output.
- The footer shows a noninteractive English status and links to a plain-language status page; it is not a language selector.
- Unsupported language requests do not activate a translated journey.
- No Spanish or additional-language interface assets were discovered in the exact v0.25.0 base. Profile language facts remain directory data, not interface-language activation.
- Future activation requires Roger's separate approval, complete journey translation, legal/privacy/accessibility/currentness/support review, exact testing and rollback.
