> Current release: v0.66.0. Directory truth: 465 profiles, 258 attorneys, 207 firms, 236 approved attorney-to-firm relationships.

# Entity Resolution and Relationships — v0.66.0

Current visible directory truth is 456 public profiles, 249 attorneys, 207 firms, 227 approved attorney–firm relationships, 535 public HTML pages, 538 public routes/endpoints, 113 dated official or trusted source records, and 1,388 scheduled review tasks. Each approved attorney and firm retains one canonical page. The 227 approved relationships remain source-backed, dated, reciprocal, correctable, suppressible, and removable; no affiliation is inferred.

Suppression and removal now use a durable tombstone register. Active tombstones prevent stale canonical-route, search, sitemap, projection, outreach, opportunity, claim, publication, and rollback restoration. `RESTORE_PUBLIC` requires explicit authorized re-review and source, duplicate, relationship, safety, and publication acceptance.
