# Evidence Invalidation Control — v0.30.0

Every material acceptance group declares its source, data, configuration, toolchain, dependency, feature-flag, environment and artifact inputs. Any listed input change invalidates affected evidence and requires the declared rerun before acceptance can be current. v0.30.0 adds professional-outreach continuity and presentation inputs. The final outer ZIP identity remains an external post-packaging receipt.
