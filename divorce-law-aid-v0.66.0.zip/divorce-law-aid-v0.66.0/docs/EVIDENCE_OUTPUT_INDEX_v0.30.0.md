# Evidence Output Index — v0.30.0

Detailed evidence is indexed in `data/evidence-output-index-v0.30.0.json`. Full logs, inventories, matrices, requests, receipts, bindings, tests, rollback, and continuation truth remain in the package. Owner-facing delivery should identify the exact artifact and remain concise.
