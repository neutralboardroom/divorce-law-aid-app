# Experiment Cards — v0.39.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.39.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

## Multi-item local review
Hypothesis: related papers can be organized more usefully without server upload. Result: adopted locally after size, privacy, deletion and browser acceptance.

## Prepared-not-sent review package
Hypothesis: users need a coherent package without accidental transmission. Result: adopted with sensitive exclusions and two explicit boundaries.

## Receipt-chained preliminary offer
Hypothesis: fair allocation needs auditable response/expiry continuity. Result: locally verified synthetic foundation; live gate remains closed.
