# Feature Classification — v0.63.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.46.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

- Canonical directory, local planning tools, workspace recovery, review-package digest, duplicate detection and synthetic receipt-chain recovery: implemented and locally verified; browser acceptance remains blocked by administrator policy.
- V7 authority, rule successorship, applicability ledger and product readiness: implemented and independently validated.
- Marital agreement drafts: implemented preparation-only; public legal activation gated.
- Smarter Justice projection/handoff: local fail-closed adapter evidence only; current shared maturity remains D0.
- Central accounts, claims, payments, membership projection, confidential release, opportunity delivery, outreach delivery, server uploads, OCR, external AI, filing, service, signatures, notarization, production deployment, post-deployment verification and live acceptance: closed or blocked.
