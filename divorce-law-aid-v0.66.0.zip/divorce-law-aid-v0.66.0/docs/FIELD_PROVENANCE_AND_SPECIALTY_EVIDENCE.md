# Field Provenance and Specialty-Evidence Standard

Material profile facts retain, where applicable: source ID, source tier, publisher, URL/dataset identifier, retrieval date, supported facts, external ID, supplied-by state, review state, verification state, last verification, correction history, and use limitations.

Keep separate:

- Official identity and credential facts.
- Public practice-source facts.
- Professional-supplied facts.
- Firm-authority facts.
- Portal-specific family-law evidence.
- Claim and account state.
- Membership, billing, Sponsored/Featured, and opportunity state.
- Staff notes and private evidence.

Family-law eligibility requires explicit evidence such as a family-law practice page, an attorney biography naming relevant work, a supported firm assignment, or an approved professional submission. A license, name, office, firm colleague, search snippet, or payment does not establish specialty relevance.

## v0.15.0 accepted source floor

The 14-record batch uses Tier 2 firm-controlled sources dated July 29, 2026. Every record includes an explicit family-law practice statement and field list. Firm sources support firm business facts only; official attorney identity, current registration, availability and attorney rosters remain separately unreviewed.
