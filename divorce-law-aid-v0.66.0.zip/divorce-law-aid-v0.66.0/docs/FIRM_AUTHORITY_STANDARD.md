# Firm Authority Standard

A firm claimant must prove authority for the exact firm. Authority for a firm does not silently authorize protected changes to an individual attorney's identity, credentials, specialty or affiliation. Attorney-firm links require separate evidence and accountable bidirectional review. Former administrators, competing claims and limited-scope delegates remain pending or disputed until reviewed.
