# Launch Capability Matrix — v0.30.0

The exact machine-readable record is `data/launch-capability-matrix-v0.30.0.json`.

The Tier A public-information, directory/profile, safe-tool/Document Help, and attorney-demonstration source capabilities are **LOCALLY ACCEPTED**. They are **not deployed**, **not post-deployment verified**, and **not live accepted**.

Real-browser/manual accessibility, qualified New York/New Jersey review, support/safe-contact operations, and staging/production deployment are `OWNER OR EXTERNAL ACTION REQUESTED`. Tier B is in preparation with its professional paths at D0. Tier C is not selected. Tier D is deferred with evidence. Tier E is not selected.

Owner approval, deployment, post-deployment verification, and live acceptance are separate fields and receipts. None is inferred from another.
