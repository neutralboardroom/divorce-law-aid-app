# Learning Lineage — v0.27.0

Machine-readable record: `data/learning-lineage-v0.27.0.json`.

The target artifact implements the v0.26.0 negative learnings on partial truth assertions, stale NVIL counts, ambiguous authority, unsafe rollback, and circular confirmation. Propagation remains evidence-gated: the source defect is verified, the v0.27.0 target implementation is present, and exact target acceptance becomes complete only after final artifact testing. No downstream portal may call the adaptation verified merely because this prompt or document exists.
