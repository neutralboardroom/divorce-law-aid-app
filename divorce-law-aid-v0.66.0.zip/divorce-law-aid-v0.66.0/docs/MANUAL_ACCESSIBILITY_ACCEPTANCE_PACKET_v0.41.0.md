# Manual Accessibility and Physical-Device Acceptance — v0.41.0

Status: **ready after exact staging deployment; not accepted**.

Packet ID: `DLA-0.41.0-MANUAL-ACCESSIBILITY-ACCEPTANCE`  
Packet digest: `165080a433ff0446a1e1962f5454eb88dc1d38f50c94ea7aae655ffe9b992f0a`

## Representative routes

- `/`
- `/start.html`
- `/documents.html`
- `/directory.html`
- `/attorneys/frank-p-marciano/`
- `/firms/aretsky-law-group/`
- `/professional-follow-up.html`
- `/account.html`
- `/contact.html`
- `/accessibility.html`

## Required coverage

### viewports
- desktop 1440x900
- tablet 768x1024
- phone 390x844
- narrow phone 320x568

### interaction
- keyboard only
- visible focus
- menu expansion
- form labels/errors
- quick exit
- privacy controls
- print

### zoomReflow
- 200% browser zoom
- 400% reflow where applicable
- large text
- landscape phone

### assistiveTechnology
- desktop screen reader
- mobile screen reader

### motionContrast
- reduced motion
- forced colors/high contrast where available

## Receipt boundary

Bind the completed record to the immutable deployment ID and release candidate. Private user data and credentials must not be used.
