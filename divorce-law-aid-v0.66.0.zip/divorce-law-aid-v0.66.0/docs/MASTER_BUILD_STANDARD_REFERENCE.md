> Current release: v0.66.0. Directory truth: 465 profiles, 258 attorneys, 207 firms, 236 approved attorney-to-firm relationships.

# Master Build Standard Reference

The exact twenty-sixth-pass prompt remains the current portal-local family-master descendant.

- SHA-256: `fd9e66a351067b6c02891c9474a4bc52edcbde552ae5706738d00960e6d4573f`
- Exact size: 599027 bytes
- Exact lines: 12776
- Packaged path: `docs/CURRENT_BUILD_MASTER_INSTRUCTION_TWENTY_SIXTH_PASS.txt`
- Current observed transport filename: `Four_Initial_Legal_Micro_Portals_Reusable_Master_Build_Prompt_Twenty_Sixth_Pass_Prompt_Self_Identity_Binding_Current_Pass_Marker_Derivation_Stale_Marker_Regression_2026-07-31(6).txt`
- Append-only alias registry: `data/prompt-transport-alias-registry-v0.46.0.json`
- Exact immutable parent SHA-256: `1d4d528fbeae3e4c7da6b1ccb92f10f9bb8e2da9fe6debe81a71db1e39674372`
- Durable baseline: `DRB-2026-07-31-DUR001-DUR043-V2`

Transport filenames are metadata only. Shared boundaries remain governed by the exact last-known-compatible twenty-fourth-pass family/sixth-pass central pair until reciprocal propagation is accepted.

The obsolete three-portal reusable instruction and superseded family-master passes are historical references only and are non-controlling.
