# Mode, Authority, and Deliverable Record — v0.30.0

- Active mode: **Mode A — dedicated Divorce Law Aid portal builder**.
- Authorized repository: `divorce-law-aid-v0.30.0/` only.
- Smarter Justice and all other portal repositories are read-only coordination constraints and were not modified.
- Deliverable: one exact-tested `divorce-law-aid-v0.30.0.zip`.
- Central register mutation is not authorized. The product-local row and Owner Assistance Requests remain `PENDING CANONICAL RECEIPT` until Smarter Justice coordination reconciles them.
