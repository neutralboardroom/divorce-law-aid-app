# Next Version Improvement List — v0.66.0

## Completed in v0.66.0

- DLA-170 — Private local-only mediation preparation with explicit safety, coercion, confidentiality, voluntariness, independent-review and no-agreement boundaries.
- DLA-171 — Five current source-reviewed Rower LLC attorney profiles and five approved firm relationships.

## Still externally blocked

- Exact connected Smarter Justice commercial authority and live checkout/entitlement evidence.
- Exact connected central AI gateway, dark deployment, canary, monitoring and stabilization evidence.
- Repository connection, Render deployment, DNS/TLS, human acceptance and public live acceptance.
- Current official attorney-registration, office-address and availability checks before verified, claimed, featured, outreach or opportunity states.
