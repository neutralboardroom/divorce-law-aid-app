# Next Version Improvement List — v0.63.0

The canonical list is `data/next-version-improvements.json`.

## Completed in v0.63.0

- DLA-166 — Private court-appearance preparation with strict no-external-action boundaries.
- DLA-167 — Current-source, exact-successor and current-batch evidence validation.

## Still externally blocked

- Central billing/entitlement identity and live payment evidence.
- Deployed central AI gateway identity, controlled canary and stabilization evidence.
- Repository, Render, DNS/TLS, human acceptance and live-operation evidence.
