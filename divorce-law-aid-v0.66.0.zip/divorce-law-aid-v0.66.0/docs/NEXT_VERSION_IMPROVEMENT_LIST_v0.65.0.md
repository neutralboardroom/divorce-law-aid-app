# Next Version Improvement List — v0.65.0

The canonical list is `data/next-version-improvements.json`.

## Completed in v0.65.0

- DLA-168 — Private local-only parenting-plan preparation with explicit child-safety, no-identifying-data and no-legal-conclusion boundaries.
- DLA-169 — Four current source-reviewed Vacca Family Law Group attorney profiles and four approved firm relationships.

## Still externally blocked

- Central billing/entitlement identity and live payment evidence.
- Deployed central AI gateway identity, controlled canary and stabilization evidence.
- Repository, Render, DNS/TLS, human acceptance and live-operation evidence.
