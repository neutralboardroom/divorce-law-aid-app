# OpenAI-only central-gateway portal implementation — v0.62.0

- AI launch batch: SJP-OPENAI-LIVE-2026-08-03-BATCH-02
- Portal role: legal micro-portal
- Tool: divorce-preparation-summary
- Maturity: TESTED
- Feature state: DISABLED
- AI opening decision: NO_GO
- Direct OpenAI client or key in portal: prohibited
- Deterministic non-AI fallback: available
- Synthetic evaluation: 6/6 passed
- Production OpenAI calls: 0

The portal adapter calls only a registered tool on the Smarter Justice central gateway. It derives portal and tool identity server-side, validates structured input and output, rejects unknown fields and instruction-like content, records only nonsensitive outcome categories, and fails safely to deterministic guidance. An exact deployed central gateway contract, service identity, model/prompt/source identities, controlled live smoke, cost controls, and stabilization evidence are still required before the tool may open.
