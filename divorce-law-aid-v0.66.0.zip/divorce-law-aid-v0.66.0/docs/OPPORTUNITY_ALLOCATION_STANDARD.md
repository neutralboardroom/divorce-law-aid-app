# Opportunity Allocation Standard — v0.39.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.39.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

Active paid monthly membership or a covered firm seat is threshold eligibility only. Verification, specialty, jurisdiction, conflict readiness, privacy, support, capacity and portal gates remain separate. Deterministic oldest-last-offer-first selection produces a receipt. Every offer, response, expiration or withdrawal links to the prior digest. Approved withdrawal reasons are gate closed, capacity paused, recipient suppressed, opportunity cancelled and support hold. Cancellation does not advance. Confidential details remain unreleased and all live gates remain closed.
