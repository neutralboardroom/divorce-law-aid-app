# Opportunity evidence reproducibility — v0.45.0

State: **SYNTHETIC OPPORTUNITY EVIDENCE REPRODUCIBILITY PREPARED**

- Scope: closed-gate synthetic allocation and offer-lifecycle evidence only.
- Both fixtures carry explicit clocks.
- Repeating either command must produce byte-identical JSON and the same receipt chain.
- Operational current-time evidence is permitted only as new operational evidence, never as a substitute for deterministic release acceptance.
- No confidential details, live delivery, client, lead, member or outcome claim is created.

Simple fixture output SHA-256: `723b8c077cdb0bbf10b6a5ba1aa765141a76757074a6d9400c6cdcaef22bee76`.
Lifecycle fixture output SHA-256: `9e482affc37398c7b5cd5987c17ffc21eb5a43bcdb4c28b1940644eac7d63dd5`.
