# Opt-Out and Do-Not-Contact Standard

An opt-out, complaint, removal request, death notice, impersonation concern or suppression trigger stops future outreach. Do-not-contact applies across channels; another channel cannot be used to evade it. The executable DNC register contains no real entries in this release and stores only minimal identifiers/reasons when used.
