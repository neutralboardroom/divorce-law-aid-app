# Outreach Batch Approval

No real outreach batch is approved. Any future manual pilot must identify recipients, public-business contact sources, template version, sender, legal/privacy review, suppression checks, frequency cap, operator, reason and owner approval. The current kill switch blocks apply/delivery even if a structurally valid test batch is submitted.
