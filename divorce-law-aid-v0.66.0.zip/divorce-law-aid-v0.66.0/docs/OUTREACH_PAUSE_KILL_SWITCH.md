# Outreach Pause and Kill-Switch Standard

The active state is paused. `data/outreach-pause-state.json` is authoritative locally. The delivery operation fails closed while paused or while legal, privacy, source-rights, domain authentication, bounce/complaint, support, monitoring or owner gates remain incomplete. Restoring delivery requires an explicit newer approved state and test evidence.
