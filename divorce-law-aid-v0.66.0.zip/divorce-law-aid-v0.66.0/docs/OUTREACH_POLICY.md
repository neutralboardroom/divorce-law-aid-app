# Outreach Policy — v0.39.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.39.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

Status: PAUSED / NO DELIVERY. Outreach is a separate optional claim invitation, not profile publication or claim verification. Only lawful public professional business contacts, approved templates, accurate sender identity, free claim/correct/remove language, support, opt-out, DNC, suppression and conservative frequency controls may be used. Personal/private contacts, sensitive matter data, bought questionable lists, channel switching after opt-out and manipulative urgency are prohibited.
