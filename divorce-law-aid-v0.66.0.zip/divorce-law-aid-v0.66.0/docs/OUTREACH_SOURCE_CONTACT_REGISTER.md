# Outreach Source and Contact Register

Packaged aggregate state: 0 approved recipients and no contact list. Source records in public profiles may include public business contact fields, but no recipient becomes outreach-eligible until a separate approved batch validates source, retrieval date, suppression/DNC state, contact method and legal/privacy gate. Private or enriched personal contact information is prohibited.
