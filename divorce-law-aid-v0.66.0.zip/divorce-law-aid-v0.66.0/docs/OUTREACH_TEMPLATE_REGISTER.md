# Outreach Template Register

One synthetic/testing template is structurally approved for local validation; `liveUse` remains blocked. Required content includes accurate sender identity, profile-source explanation, free claim/correction/removal, support, no affiliation or urgency implication, and opt-out language. The executable register is `data/outreach-template-register.json`.
