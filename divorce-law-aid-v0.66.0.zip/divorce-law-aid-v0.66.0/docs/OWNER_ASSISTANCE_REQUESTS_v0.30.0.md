# Prioritized Owner Assistance Requests — v0.30.0

The exact queue is `data/owner-assistance-requests.json`. All five IDs are product-local provisional IDs pending canonical Smarter Justice receipt.

Priority order:

1. Connect the exact candidate to an approved staging host and return only the nonsecret URL, project ID, deployment ID, and timestamp.
2. After staging exists, complete the physical-device/manual accessibility script and qualified NY/NJ legal/public-language review.
3. Configure a real monitored public support/correction channel without placing credentials in chat.
4. Identify the exact current Smarter Justice contract or handoff for the Tier B D1 compatibility assessment; this accelerates Tier B but does not block Tier A.

Every request includes the completed prerequisites, exact action, prohibited secret content, safe confirmation, immediate builder test, rollback, fallback, dependencies, and revalidation trigger.
