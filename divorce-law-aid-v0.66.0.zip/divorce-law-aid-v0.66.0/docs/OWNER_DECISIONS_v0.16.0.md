# Owner Decisions Still Required — v0.16.0

Deployment date/host, exact Smarter Justice D4 environment and rollout order, support contact and staffing, legal reviewers, official-registration/currentness review owner, live claim verification operations, claim evidence providers, outreach legal/privacy approval, sender domain/SMTP, pilot cohort/template, frequency and complaint thresholds, monitoring/incident owner, backup retention, payments/sponsorship/opportunity products and broad launch approval.
