# Owner Decisions Still Required — v0.17.0

- Approve or reject a legally reviewed supported New York marital-agreement document class.
- Approve server upload/storage architecture, retention, deletion, malware controls and vendor choices before uploads.
- Approve OCR or external AI only after privacy, security, legal and quality acceptance.
- Approve Smarter Justice staging order for claims, entitlements and opportunity allocation.
- Approve paid monthly membership terms, legal review, support and allocation pilot before opening gates.
- Approve hosting, monitoring, backup/restore, incident and deployment readiness.
