# Owner Decisions — v0.18.0

- Build immediately from exact v0.17.0 using the complete-product-capabilities instruction.
- Preserve free basic claim/correction rights and central Smarter Justice authority.
- Keep deployment and all live sensitive/commercial gates closed without separate approval.
- Continue mandatory lawful profile growth.
- Preserve bright-white, clean, modern design and avoid decorative pills or unnecessary redesign.
