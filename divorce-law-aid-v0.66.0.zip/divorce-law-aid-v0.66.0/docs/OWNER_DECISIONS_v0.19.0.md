# Owner Decisions — v0.19.0

No new irreversible owner decision was required. The build follows the standing decisions that basic claim/correction is free; payment is only a threshold for future opportunity eligibility; public pages remain on the portal; central account/claim/billing authority remains in Smarter Justice; and deployment or gated live activation requires Roger's explicit approval.

Owner approval remains required before deployment, public legal activation of marital drafts, live accounts/claims, paid membership, opportunity delivery, confidential release, outreach delivery, server uploads, OCR, outside AI, filing, service, signatures or notarization.
