# Owner Decisions — v0.21.0

Roger explicitly corrected the firm-heavy profile-growth pattern and directed the builder to continue v0.21.0 while adding individual attorneys. The release therefore treats individual-attorney pages as the primary growth workstream and does not count existing linked firms as new additions.

No irreversible or live-gate decision was required. Deployment, live claims, payments, outreach delivery, server uploads, OCR, external AI, marital-draft legal activation, confidential release and opportunity delivery remain closed. Logo approval remains deferred.
