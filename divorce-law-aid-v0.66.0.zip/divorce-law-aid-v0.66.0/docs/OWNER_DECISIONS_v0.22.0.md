# Owner Decisions — v0.22.0

1. Individual-attorney growth remains the primary directory workstream.
2. No firm is counted as a v0.22.0 addition.
3. Public unclaimed attorney seeds may be published only with source-supported specialty evidence and an explicit official-registration-pending disclosure.
4. Basic correction, removal and claim rights remain free.
5. Every live, sensitive and commercial gate remains closed.
