# Owner Decisions — v0.23.0

- Continue individual-attorney growth; do not return to firm-only expansion.
- Preserve unique full attorney and firm pages and free basic claim/correction rights.
- Keep official registration separate from biography/specialty evidence.
- Keep payment as threshold eligibility only and all live opportunity delivery closed.
- Apply shared and Divorce Law Aid requirements from the refined four-portal command; do not import Domestic Violence Aid organization or Stop Sign Project behavior into this repository.
- Do not deploy or activate sensitive/commercial gates without exact evidence and Roger’s approval.
