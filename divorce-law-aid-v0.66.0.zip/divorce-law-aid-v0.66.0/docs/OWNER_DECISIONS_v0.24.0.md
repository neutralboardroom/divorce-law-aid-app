# Owner Decisions — v0.24.0

1. In-person New York attorney outreach is imminent; first-impression quality is launch critical.
2. Individual-attorney growth is nonnegotiable. Firm profiles may also be added, with or without attorney links, but firm growth must never mask weak attorney growth.
3. Owner-recorded pilot planning range is $10–$20 per attorney per month, subject to final central Smarter Justice confirmation before sale.
4. Membership value language may use qualified cost comparisons and explain that one suitable retained matter could cover many months or more than a year depending on the practice and matter; it must not promise leads, clients, revenue, ranking, exclusivity, or ROI.
5. New York City Justice Booth status is PLANNED only: not scheduled, active, completed, or location-verified.
6. No gated live feature is opened without exact evidence and explicit approval.
