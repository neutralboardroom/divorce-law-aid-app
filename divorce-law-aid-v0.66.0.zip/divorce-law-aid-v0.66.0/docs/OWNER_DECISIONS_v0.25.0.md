# Owner Decisions — v0.25.0

- Individual-attorney growth remains nonnegotiable.
- Law-firm profiles may be added when useful, but must be counted separately and must not mask insufficient individual-attorney growth.
- v0.25.0 therefore adds 23 attorneys and counts zero new firms.
- Basic claiming, verification, correction and approved editing remain free.
- No live claim, payment, membership, outreach, confidential-release, opportunity or deployment gate may open without exact evidence and explicit approval.
