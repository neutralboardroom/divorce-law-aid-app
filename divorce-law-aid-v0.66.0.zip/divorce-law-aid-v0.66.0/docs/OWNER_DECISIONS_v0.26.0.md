# Owner Decisions — v0.26.0

- English is the only active public interface language for the current build and initial launch phase.
- Spanish and additional languages remain deferred and inactive until separately authorized and fully accepted.
- Individual-attorney growth remains prominent; no law firm is counted as new v0.26.0 growth.
- Basic profile claim, correction and approved editing remain free.
- Payment does not buy verification, organic rank, endorsement or guaranteed opportunities.
- Justice Booth remains PLANNED only.
- No deployment or live gated capability is authorized by this release.
