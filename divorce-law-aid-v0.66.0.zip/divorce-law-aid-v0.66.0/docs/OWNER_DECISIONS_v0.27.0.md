# Owner Decisions — v0.27.0

- Act immediately from the exact authoritative v0.26.0 artifact; do not stop at audit or recommendations.
- Make only justified improvements, but investigate proactively across the complete product and release system.
- English remains the only active public language; ordinary translation expansion is deferred.
- Preserve canonical attorney and firm pages, source-backed relationships, coherent Document Help, attorney outreach, professional follow-up, privacy, security, and fail-closed central foundations.
- Correct the entire stale current-truth defect family, not one number.
- Keep prompts, implementation truth, external acceptance, deployment, legal review, and live operations as separate evidence states.
- Use self-reference-safe outer ZIP identity: compute final SHA-256 and exact size after packaging rather than embedding recursively.
- Deliver one direct final ZIP link.
