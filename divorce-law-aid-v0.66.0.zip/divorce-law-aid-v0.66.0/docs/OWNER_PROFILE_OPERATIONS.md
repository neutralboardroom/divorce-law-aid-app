# Owner and Staff Profile Operations — v0.39.0 current-use revalidation

Revalidation state: substantive safeguards remain current in v0.39.0 unless a more specific current record controls. Historical release quantities inside examples remain historical and are not current totals.

Local protected CLI operations support: profile batch dry-run/apply, candidate review, currentness reports, official/link review ledgers, relationship decisions, claim-decision dry-run/apply/report, publication decision dry-run/apply/report and outreach dry-run/report. Sensitive actions require operator identity, reason, revision and audit. Routine operations do not require editing public HTML, but production authentication/MFA and central staff workflows remain owner-dependent.
