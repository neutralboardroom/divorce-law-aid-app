# Product Maturity Map — v0.66.0

- Public local source experience: implemented and under exact-artifact acceptance.
- Mediation preparation organizer: local-only, fail-closed, no sensitive data, no legal or mediation decision.
- Directory profiles: public-unclaimed, registration-pending, availability-unverified.
- Billing and entitlements: contract-ready, not connected.
- AI: tested, disabled, `NO_GO`.
- Repository, deployment, post-deployment and live acceptance: closed and unclaimed.
