# Professional handoff import transaction atomicity — v0.47.0

State: **PROFESSIONAL HANDOFF IMPORT TRANSACTION ATOMICITY PREPARED**

Canonical professional imports cannot bypass propagation. Projection, suppression, the prior last-known-good record, the complete public tree, and route inventory are one recoverable transaction. A propagation failure restores every declared data and public-surface boundary before returning an error. Direct propagation uses the same fail-closed public-surface snapshot rule.

Validation: `node scripts/validate-professional-handoff-transaction-controls.js`.
