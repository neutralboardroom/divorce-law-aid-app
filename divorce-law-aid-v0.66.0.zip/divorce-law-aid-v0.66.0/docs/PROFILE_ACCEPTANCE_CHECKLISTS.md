> Current release: v0.66.0. Directory truth: 460 profiles, 253 attorneys, 207 firms, 231 approved attorney-to-firm relationships.

# Profile Acceptance Checklists — v0.66.0

Current acceptance scope: 233 canonical attorney pages, 207 canonical firm pages, 440 visible directory records, and 121 reciprocal approved relationships. Every accepted entity must retain one canonical URL, source/currentness boundaries, correction/removal entry, mobile/accessibility foundations, and payment-neutral identity.

Suppression acceptance additionally requires canonical route/search/sitemap/internal-link/export/cache/outreach/opportunity/projection removal and stale-restoration prevention. Restoration requires explicit authorized re-review.
