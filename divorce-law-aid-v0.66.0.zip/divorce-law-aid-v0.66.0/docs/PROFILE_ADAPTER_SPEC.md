> Current release: v0.66.0. Directory truth: 465 profiles, 258 attorneys, 207 firms, 236 approved attorney-to-firm relationships.

# Smarter Justice Read-Only Profile Adapter — v0.66.0

The executable projection state uses historical contract version `1.4.0` and adapter version `0.66.0`. `lib/professional-data.js`, projection files, maturity records, truth records, and tests must agree. Neither number proves current central compatibility.

The current projection contains 0 records. Complete-ladder maturity is **D0 NOT CURRENTLY VERIFIED** because no exact current producer artifact or mutually accepted contract was supplied. The D0–D5 ladder is sequential and skipped states are prohibited.

Supported local actions are minimized upsert, suppression, removal, and explicitly reviewed restoration. Active tombstones survive rollback and block ordinary upserts. Public-profile fields are allowlisted; private credentials, billing, family narratives, uploads, conflicts, secrets, and staff notes are prohibited.
