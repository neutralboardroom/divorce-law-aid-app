> Current release: v0.66.0. Directory truth: 460 profiles, 253 attorneys, 207 firms, 231 approved attorney-to-firm relationships.

# Profile Directory Governance — v0.66.0

The current directory contains 440 public profiles, 233 attorneys, 207 firms, 211 approved attorney–firm relationships, 516 public HTML pages, 519 public routes/endpoints, 96 dated official or trusted source records, and 1,324 scheduled review tasks. Publication, identity, claim authority, professional status, specialty eligibility, payment, opportunity eligibility, and representation remain separate states.

Ordering remains neutral and payment-independent. Durable suppression/removal tombstones propagate through canonical pages, route inventory, sitemap, sanitized APIs/search data, internal links, exports, outreach, opportunity eligibility, projection/last-known-good, and rollback. Ordinary upserts cannot restore a tombstoned profile.
